Windows source CI follow-up, 2026-10-20.
Tested code: edca2e7d00c7d3e2db32248473f24e2d2b964b27.
Run 39401465787 is the retained real failure; run 39404325605 is the rerun.
Complete job logs come from GitHub run-log ZIPs, not the partial gh run view cache.
No installer, executable, private key, SDK archive, or Actions artifact is included.
SDK 0.3.7 checks use four public SDK package files and existing local tools.
Production executable hashes describe compilation outputs, not GUI/install acceptance.
Source diffs after e63aa104 are the approved CI allowlist and one test fixture fix.
Historical e63aa104 RED/GREEN archive remains separate and unchanged.
