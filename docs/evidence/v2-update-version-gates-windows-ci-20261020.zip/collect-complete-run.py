"""Read-only source CI collection. Does not dispatch, rerun, or upload anything."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

run_id, expected_sha = sys.argv[1:]
assert run_id.isdecimal() and re.fullmatch(r"[0-9a-f]{40}", expected_sha)
root = Path(__file__).parent / f"run-{run_id}"
root.mkdir(exist_ok=True)
base = "repos/Auto-Plugin/milkup"


def api(path, filename):
    result = subprocess.run(["gh", "api", f"{base}/{path}"], capture_output=True)
    if result.returncode:
        message = re.sub(
            r'https://[^\s"<>]+',
            "[download URL redacted]",
            result.stderr.decode(errors="replace"),
        )
        (root / (filename + ".error.txt")).write_text(message)
        raise RuntimeError(f"Read failed: {filename}; sanitized details saved")
    (root / filename).write_bytes(result.stdout)
    return result.stdout


run = json.loads(api(f"actions/runs/{run_id}", "run-final.json"))
assert run["head_sha"] == expected_sha
assert run["status"] == "completed", "Not a final result"
jobs = json.loads(api(f"actions/runs/{run_id}/jobs?per_page=100", "jobs.json"))
artifacts = json.loads(
    api(f"actions/runs/{run_id}/artifacts?per_page=100", "artifacts.json")
)
assert artifacts["total_count"] == 0
for job in jobs["jobs"]:
    api(
        f"check-runs/{job['id']}/annotations?per_page=100",
        f"annotations-{job['id']}.json",
    )
logs = api(f"actions/runs/{run_id}/logs", "run-logs.zip")
archive = zipfile.ZipFile(io.BytesIO(logs))
assert "0_desktop-source.txt" in archive.namelist()
log = archive.read("0_desktop-source.txt").decode("utf-8-sig")
(root / "complete-job.log").write_text(log)
lines = [line.split("Z ", 1)[-1] for line in log.splitlines()]
parsed = {}
for name in [
    "source.json",
    "phases.json",
    "rust-test-result.json",
    "production-binary-manifest.json",
    "public-plugins/staged-bundles.json",
]:
    start = lines.index("##[group]" + name)
    end = next(
        index
        for index in range(start + 1, len(lines))
        if lines[index] == "##[endgroup]"
    )
    parsed[name] = json.loads("\n".join(lines[start + 1 : end]))
    (root / ("parsed-" + name.replace("/", "-"))).write_text(
        json.dumps(parsed[name], indent=2) + "\n"
    )
assert parsed["source.json"]["commit"] == expected_sha
summary = {
    "run": run_id,
    "commit": expected_sha,
    "conclusion": run["conclusion"],
    "url": run["html_url"],
    "artifacts": artifacts["total_count"],
    "phases": [
        {"name": phase["name"], "status": phase["status"]}
        for phase in parsed["phases.json"]
    ],
    "rustTestResult": parsed["rust-test-result.json"],
    "productionBinarySha256": parsed["production-binary-manifest.json"]["sha256"],
    "testSummaries": [line for line in lines if line.startswith("test result:")],
    "completeLogSha256": hashlib.sha256(log.encode()).hexdigest(),
    "rawLogZipSha256": hashlib.sha256(logs).hexdigest(),
}
if run["conclusion"] == "success":
    assert len(summary["phases"]) == 15
    assert all(phase["status"] == "passed" for phase in summary["phases"])
    assert summary["rustTestResult"]["status"] == "passed"
    assert parsed["production-binary-manifest.json"]["status"] == "passed"
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
