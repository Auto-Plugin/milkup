"""Read and verify this checkpoint ZIP without extracting or executing members."""
import hashlib,json,sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as archive:
    names=archive.namelist()
    assert len(names)==len(set(names)), 'duplicate ZIP names'
    index=json.loads(archive.read('index.json'))
    assert set(names)==set(index['files'])|{'index.json'}, 'unexpected ZIP members'
    for name,expected in index['files'].items():
        data=archive.read(name)
        assert len(data)==expected['bytes'], name
        assert hashlib.sha256(data).hexdigest()==expected['sha256'], name
print(f"Verified {len(index['files'])} indexed members")
