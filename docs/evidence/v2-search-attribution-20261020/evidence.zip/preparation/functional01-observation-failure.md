首轮在 Source 前五项通过后失败。初版测试在确认 UI searching 后，为 window 注册捕获 keydown 监听器；它在先注册的应用处理器之后执行。对 Ctrl+N 记录到 trusted=true、searching=false、只有新 scheduled 记录，再断言 searching=true 失败。切换后文档未脏、光标0、结果0/0。该记录不能证明切换时扫描仍在运行，也不当作产品跨文档失败。

限定修正：查询前安装 PerformanceObserver 保存最多512条无正文阶段记录；切换前同时要求 query=x、loading、controller-start、无controller-complete。键盘捕获只证明 trusted；切换后要求旧run记录 controller-cancel 且无controller-complete，并核验新文档/重开原文件。原失败JSON、截图和exit1均保留。
