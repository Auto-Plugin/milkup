// Explicit research builds only. No query, document ID, path or text is accepted.
export const searchDiagnosticsEnabled =
  typeof __MILKUP_SEARCH_DIAGNOSTICS__ !== 'undefined' && __MILKUP_SEARCH_DIAGNOSTICS__

export const SEARCH_TRACE_NAME = 'milkup:search-stage'
export const SEARCH_TRACE_LIMIT = 256
export type SearchStage =
  | 'scheduled'
  | 'debounce-fired'
  | 'run-start'
  | 'flush-start'
  | 'flush-end'
  | 'controller-start'
  | 'begin-start'
  | 'begin-end'
  | 'step-start'
  | 'step-end'
  | 'worker-create-start'
  | 'worker-create-end'
  | 'worker-post'
  | 'worker-matches'
  | 'append-start'
  | 'append-end'
  | 'worker-complete'
  | 'page-start'
  | 'page-end'
  | 'controller-complete'
  | 'controller-cancel'
  | 'controller-failed'
  | 'highlight-start'
  | 'highlight-end'
  | 'navigate-start'
  | 'navigate-end'
  | 'run-end'
type NumericField =
  | 'nativeMs'
  | 'scanMs'
  | 'initializationMs'
  | 'workerBootAt'
  | 'workerReceivedAt'
  | 'scannedBytes'
  | 'matchCount'
  | 'fallbackUtf16Units'
  | 'indexBytes'
export type SearchTrace = (
  stage: SearchStage,
  values?: Partial<Readonly<Record<NumericField, number>>>,
) => void
const fields: readonly NumericField[] = [
  'nativeMs',
  'scanMs',
  'initializationMs',
  'workerBootAt',
  'workerReceivedAt',
  'scannedBytes',
  'matchCount',
  'fallbackUtf16Units',
  'indexBytes',
]
interface TraceSink {
  mark(name: string, options: { detail: unknown }): void
  clearMarks(name: string): void
}
export function createSearchTraceRecorder(sink: TraceSink, enabled: boolean) {
  let generation = 0
  return (): SearchTrace | undefined => {
    if (!enabled) return undefined
    const run = ++generation
    let count = 0
    sink.clearMarks(SEARCH_TRACE_NAME)
    return (stage, values = {}) => {
      if (generation !== run || count >= SEARCH_TRACE_LIMIT) return
      const detail: Record<string, number | string> = {
        run,
        stage: count === SEARCH_TRACE_LIMIT - 1 ? 'trace-limit' : stage,
      }
      for (const field of fields) {
        const value = values[field]
        if (typeof value === 'number' && Number.isFinite(value)) detail[field] = value
      }
      count++
      sink.mark(SEARCH_TRACE_NAME, { detail })
    }
  }
}
export const beginSearchTrace = createSearchTraceRecorder(performance, searchDiagnosticsEnabled)
