import { describe, expect, it } from 'vitest'
import {
  createSearchTraceRecorder,
  SEARCH_TRACE_LIMIT,
  SEARCH_TRACE_NAME,
} from './search-diagnostics'

function fixture(enabled = true) {
  const entries: Array<{ name: string; detail: unknown }> = []
  const cleared: string[] = []
  return {
    entries,
    cleared,
    begin: createSearchTraceRecorder(
      {
        mark(name, { detail }) {
          entries.push({ name, detail })
        },
        clearMarks(name) {
          cleared.push(name)
          entries.length = 0
        },
      },
      enabled,
    ),
  }
}
describe('bounded build-only search diagnosis', () => {
  it('does nothing when the build flag is disabled', () => {
    const f = fixture(false)
    expect(f.begin()).toBeUndefined()
    expect(f.entries).toEqual([])
    expect(f.cleared).toEqual([])
  })
  it('retires old runs and keeps only the latest bounded trace', () => {
    const f = fixture()
    const old = f.begin()!
    old('scheduled')
    const current = f.begin()!
    old('controller-complete')
    for (let i = 0; i < 1000; i++) current('step-end', { scannedBytes: i })
    expect(f.entries).toHaveLength(SEARCH_TRACE_LIMIT)
    expect(f.entries.at(-1)?.detail).toMatchObject({ stage: 'trace-limit', run: 2 })
    expect(f.cleared).toEqual([SEARCH_TRACE_NAME, SEARCH_TRACE_NAME])
  })
  it('records only allowed finite numeric metadata, never arbitrary content', () => {
    const f = fixture()
    const values = { nativeMs: 2, scanMs: NaN, indexBytes: Infinity, query: 'private text' }
    f.begin()!('step-end', values)
    expect(f.entries).toEqual([
      { name: SEARCH_TRACE_NAME, detail: { run: 1, stage: 'step-end', nativeMs: 2 } },
    ])
  })
})
