declare const __MILKUP_VERSION__: string
declare const __MILKUP_PLUGIN_SDK_VERSION__: string
declare const __MILKUP_SEARCH_DIAGNOSTICS__: boolean
