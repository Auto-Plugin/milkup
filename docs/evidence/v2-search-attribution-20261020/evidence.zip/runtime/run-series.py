import subprocess,pathlib,json,datetime,hashlib,sys,shlex
root=pathlib.Path(__file__).resolve().parent.parent
runtime=root/'runtime';binary=str(root/'candidate-diagnostic01/milkup-desktop');sha=hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest()
plan=[('search-attribution-source-01','latency','source'),('search-attribution-live-01','latency','live')]
for name,kind,option in plan:
 record=root/'control'/(name+'-execution.json');assert not record.exists()
 row={'run':name,'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binarySha256':sha}
 try:
  subprocess.run(['python3',str(runtime/'driver-control.py'),'start',name,binary,sha],check=True)
  command='source '+shlex.quote(str(runtime/'run-env.sh'))+' '+shlex.join([name,binary,sha])+'\n'
  if kind=='cold':
   command+='source '+shlex.quote(str(runtime/'cold-env.sh'))+'\nexport MILKUP_P6_FORMAT='+shlex.quote(option)+'\nexec node '+shlex.quote(str(root/'cold-source/tests/native/tauri-p6-lifecycle.mjs'))
  else:
   command+='export MILKUP_LATENCY_BYTES=10485760 MILKUP_LATENCY_LINE_BYTES=64 MILKUP_LATENCY_CYCLES=20 MILKUP_LATENCY_HISTORY_CHECK=1 MILKUP_LATENCY_MODE='+shlex.quote(option)+'\nexec node tests/native/tauri-production-latency.mjs'
  row['command']=['bash','-c',command]
  with (root/'control'/(name+'-harness.log')).open('x') as log:
   result=subprocess.run(row['command'],cwd='/workspace/milkup',stdout=log,stderr=subprocess.STDOUT,timeout=300)
  row['exitCode']=result.returncode
 except Exception as e:row['error']=str(e)
 finally:
  subprocess.run(['python3',str(runtime/'driver-control.py'),'stop',name],check=True)
  row['endedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record.write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 if row.get('exitCode')!=0:break
