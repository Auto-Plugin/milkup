Architecture blocker checkpoint, not a successful recovery implementation.
Only synthetic private temporary trust directories are tested.
Attempt 1 is the retained missing /tmp build-cache failure.
Attempt 2 proves feasibility boundaries; full-rust-tests.log is the final suite after adding cross-process contention assertions.
The two child test invocations are part of one parent test, not additional tests counted toward the full-suite total.
No installer, executable, private key or real user trust record is included.
