# Bounded official primitive review

Windows sources:

- https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntqueryinformationprocess
- https://learn.microsoft.com/en-us/windows/win32/devnotes/process_telemetry_id_information_type
- https://learn.microsoft.com/en-us/windows/win32/api/minwinbase/ns-minwinbase-create_process_debug_info

The documented image-name result is a pathname. The listed telemetry fields are
metadata, including checksum/time, not a corresponding read-only image handle
or cryptographic image proof. No sufficient ordinary self-query contract was
identified in this bounded review; this is not a claim of universal impossibility.
The debugger creation event does document a process image file handle (nullable).
Using it would require trusted launch/event coordination and target-system
validation. No debugger, process attach, privilege or launch change was performed.

Apple sources (official DocC JSON successfully read; URLs in fetch metadata):

- https://developer.apple.com/documentation/security/seccodecopyself(_:_:)
- https://developer.apple.com/documentation/security/seccodecheckvalidity(_:_:_:)
- https://developer.apple.com/documentation/security/seccodecopystaticcode(_:_:_:)

SecCodeCopySelf provides the dynamic code object, without itself proving validity.
Dynamic validity checking supports explicit code requirements and protects
against source-filesystem changes. That is a possible platform code-identity
contract, not automatically the current entire-file SHA-256 contract or complete
payload integrity. Static-object association explicitly lacks a guaranteed secure
link, so reopening its path is not a proven running-image handle substitute.
Minimum next resources: a reviewed signed platform-identity requirement contract,
macOS/Security.framework target validation and controlled signed test images.
No implementation/framework dependency or credential change was performed.

The Web tool's two Apple Markdown fetches failed with HTTP/tool status 400,
Unsupported content-type: text/markdown. The same public official documentation
was then read through three DocC JSON endpoints. Full fetched documents stay
local and are excluded from the deliverable archive; only hashes and this short
paraphrase are included. No candidate image or real updater was run for research.
