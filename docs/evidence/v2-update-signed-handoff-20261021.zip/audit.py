from pathlib import Path
import hashlib,json,subprocess

root=Path('/workspace/milkup')
out=Path('/workspace/milkup-update-handoff-evidence')
baseline='5dd78a4fc06078c2259b54a4c4895cc3a6ded075'
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
sources=[
 'apps/desktop/src-tauri/src/update_handoff.rs','apps/desktop/src-tauri/src/update_handoff_tests.rs',
 'apps/desktop/src-tauri/src/update_identity.rs','apps/desktop/src-tauri/src/update_policy.rs',
 'apps/desktop/src-tauri/src/update_transaction.rs','apps/desktop/src-tauri/src/update_transaction_tests.rs',
 'apps/desktop/src-tauri/src/updates.rs','vendor/tauri-plugin-updater/src/updater.rs',
 'vendor/tauri-plugin-updater/MILKUP-PATCH.diff','vendor/tauri-plugin-updater/MILKUP-PROVENANCE.json',
]
hashes={}
for name in sources:
 data=(root/name).read_bytes(); hashes[name]=sha(data)
 (out/Path(name).name).write_bytes(data)
updates=(root/sources[6]).read_text()
block='''
#[allow(dead_code)]
#[path = "update_handoff.rs"]
mod handoff;
'''
assert updates.replace(block,'',1)==git('show',f'{baseline}:{sources[6]}').decode()
policy=(root/sources[3]).read_text()
old_policy=git('show',f'{baseline}:{sources[3]}').decode()
assert policy[policy.index('    fn validate('):]==old_policy[old_policy.index('    fn validate('):]
identity=(root/sources[2]).read_text()
old_identity=git('show',f'{baseline}:{sources[2]}').decode()
def current_observer(text):
 start=text.index('#[cfg(target_os = "linux")]\nfn read_image')
 return text[start:text.index('// A point-in-time match',start)]
assert current_observer(identity)==current_observer(old_identity)
vendor=(root/sources[7]).read_text()
old_vendor=git('show',f'{baseline}:{sources[7]}').decode()
assert vendor[vendor.index('    pub fn install('):]==old_vendor[old_vendor.index('    pub fn install('):]
unchanged=[
 'apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/update_pe.rs',
 'apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock',
 'apps/desktop/src-tauri/tauri.conf.json','apps/desktop/src-tauri/nsis-hooks.nsh',
 'vendor/tauri-plugin-updater/Cargo.toml','vendor/tauri-plugin-updater/Cargo.lock',
 'vendor/tauri-plugin-updater/src/windows_install.rs','vendor/tauri-plugin-updater/src/commands.rs',
 'vendor/tauri-plugin-updater/guest-js','vendor/tauri-plugin-updater/permissions',
 '.github/workflows','packages','plugins','apps/desktop/src','release','pnpm-lock.yaml',
 'tests/fixtures/updates',
]
for path in unchanged:
 assert (root/path).exists(),path
 assert not git('diff',baseline,'--',path),path
dep=(root/'apps/desktop/src-tauri/target/debug/libmilkup_desktop_lib.d').read_bytes()
assert b'/update_handoff.rs' in dep and b'/update_handoff_tests.rs' not in dep
(out/'normal-library-dependencies.d').write_bytes(dep)
tests=(out/'full-rust-tests.log').read_text()
assert '238 passed; 0 failed; 5 ignored' in tests
assert tests.count('HANDOFF CHILD ')==14
assert tests.count('HANDOFF KILL ')==2
assert '0 passed; 1 failed' in (out/'late-cancel-red.log').read_text()
assert 'Finished `dev` profile' in (out/'normal-build.log').read_text()
assert 'pass 2' in (out/'vendor-tests.log').read_text()
artifact=root/'apps/desktop/src-tauri/target/debug/libmilkup_desktop_lib.rlib'
hasher=hashlib.sha256()
with artifact.open('rb') as f:
 while chunk:=f.read(1024*1024):hasher.update(chunk)
official=[]
for path in sorted(out.glob('apple-*.json')):
 official.append({'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'excluded_from_delivered_archive':True})
result={
 'baseline':baseline,'branch':git('branch','--show-current').decode().strip(),
 'source_sha256':hashes,'unchanged_paths':unchanged,
 'host_install_path_unchanged_except_private_module_declaration':True,
 'policy_validation_watermark_and_authorization_unchanged':True,
 'linux_current_image_observer_unchanged':True,
 'vendor_install_and_platform_launch_tail_byte_identical':True,
 'normal_build_includes_coordinator_excludes_tests':True,
 'normal_library':{'bytes':artifact.stat().st_size,'sha256':hasher.hexdigest(),'not_delivered':True},
 'full_rust_tests':{'passed':238,'failed':0,'existing_ignored':5},
 'vendor_gate_tests':{'passed':2,'failed':0},
 'handoff_subprocesses':{'restart_cases':14,'paused_writers_killed':2,'lock_contenders':2,'post_kill_inspectors':2,'total':20,'power_loss_validation':False},
 'preserved_failure':'late-cancel-red.log: cancellation during final retain authorization returned late success; fixed and full suite passed',
 'official_document_hashes_only':official,
 'real_installer_or_candidate_executed':False,'real_release_verified':False,
 'windows_or_macos_runtime_validation':False,'production_startup_wired':False,
 'health_confirmed':False,
}
(out/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(out/'checkpoint.diff').write_bytes(git('diff',baseline,'--',*sources))
print(json.dumps(result,ensure_ascii=False,indent=2))
