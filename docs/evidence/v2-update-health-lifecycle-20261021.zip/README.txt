Test-only health lifecycle contract. Baseline 40e53428e64a4effef2378ea6cbcab8f3be3b11a.
No production installer receipt, health probe, durable journal or rollback executor is implemented.
Completion and health facts are mocks; matching values is not authentication.
model-late-rejection-red.log retains a real failing model assertion, not a production updater failure.
full-rust-tests.log is the final source validation after correcting the model late-rejection boundary.
No installer, executable, third-party template copy, private key or user data is included.
Pinned official NSIS source provenance is included for independent review.
