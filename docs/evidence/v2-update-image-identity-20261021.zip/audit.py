from pathlib import Path
import hashlib, json, subprocess

root=Path('/workspace/milkup')
out=Path('/workspace/milkup-update-identity-evidence')
baseline='bdfea1171a85b81f59c499d98601a2d0873b5e8a'
def git(*args): return subprocess.check_output(['git','-C',str(root),*args])
def sha(data): return hashlib.sha256(data).hexdigest()
sources=[
 'apps/desktop/src-tauri/src/update_identity.rs',
 'apps/desktop/src-tauri/src/update_identity_tests.rs',
 'apps/desktop/src-tauri/src/update_policy.rs',
 'apps/desktop/src-tauri/src/update_transaction.rs',
 'apps/desktop/src-tauri/src/updates.rs',
 'apps/desktop/src-tauri/src/updates_tests.rs',
 'tests/fixtures/updates/generate.py',
 'tests/fixtures/updates/application-identity.json',
]
hashes={}
for path in sources:
 data=(root/path).read_bytes()
 (out/Path(path).name).write_bytes(data)
 hashes[path]=sha(data)

# Exact reconstruction proves original policy code unchanged by extracting its
# authorize body for reuse from the new read-only shared-lease entry point.
policy=(root/sources[2]).read_text()
start=policy.index('        self.authorize_locked(observation, now)')
end=policy.index('        let old = self.read()?.ok_or(',start)
original_policy=policy[:start]+policy[end:]
assert original_policy==git('show',f'{baseline}:{sources[2]}').decode()
tx=(root/sources[3]).read_text()
getter='''    pub(super) fn intent(&self) -> &Intent {
        &self.intent
    }

'''
assert tx.replace(getter,'',1)==git('show',f'{baseline}:{sources[3]}').decode()
updates=(root/sources[4]).read_text()
module='''
// Internal image evidence only; no health transition or installation wiring.
#[allow(dead_code)]
#[path = "update_identity.rs"]
mod identity;
'''
assert updates.replace(module,'',1)==git('show',f'{baseline}:{sources[4]}').decode()
unchanged=[
 'apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/update_pe.rs',
 'apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock',
 'apps/desktop/src-tauri/tauri.conf.json','apps/desktop/src-tauri/nsis-hooks.nsh',
 'vendor/tauri-plugin-updater','.github/workflows','packages','plugins',
 'apps/desktop/src','release','pnpm-lock.yaml',
 'tests/fixtures/updates/signed-manifest.json','tests/fixtures/updates/version-gates.json',
]
for path in unchanged:
 assert (root/path).exists(),path
 assert not git('diff',baseline,'--',path),path
dep=(root/'apps/desktop/src-tauri/target/debug/libmilkup_desktop_lib.d').read_bytes()
assert b'/update_identity.rs' in dep and b'/update_identity_tests.rs' not in dep
(out/'normal-library-dependencies.d').write_bytes(dep)
assert '235 passed; 0 failed; 5 ignored' in (out/'full-rust-tests.log').read_text()
assert 'Finished `dev` profile' in (out/'normal-build.log').read_text()
assert '1 passed; 0 failed' in (out/'actual-current-image.log').read_text()
assert 'read current test process image: 43072144 bytes' in (out/'actual-current-image.log').read_text()
artifact=root/'apps/desktop/src-tauri/target/debug/libmilkup_desktop_lib.rlib'
result={
 'baseline':baseline,'branch':git('branch','--show-current').decode().strip(),
 'source_sha256':hashes,'original_policy_exact_reconstruction':True,
 'transaction_only_readonly_intent_getter':True,
 'updates_only_private_module_declaration':True,'unchanged_paths':unchanged,
 'normal_build_includes_identity_and_excludes_identity_tests':True,
 'normal_library':{'bytes':artifact.stat().st_size,'sha256':sha(artifact.read_bytes()),'excluded_from_archive':True},
 'full_tests':{'passed':235,'failed':0,'existing_ignored':5},
 'initial_failures_preserved':['targeted-attempt1.log: missing trait compile failure',
    'targeted-attempt2.log: debug test executable exceeds immutable 256 MiB limit'],
 'real_current_image_test':'stripped copy of the same test harness; no candidate executed',
 'windows_current_image_supported':False,'production_installer_connected':False,
 'health_verified':False,
}
(out/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(out/'native-and-fixture.diff').write_bytes(git('diff',baseline,'--',*sources))
print(json.dumps(result,ensure_ascii=False,indent=2))
