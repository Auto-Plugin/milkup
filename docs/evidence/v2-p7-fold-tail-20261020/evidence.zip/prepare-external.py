from pathlib import Path
import hashlib,json,os,shutil,tarfile
repo=Path('/workspace/milkup');out=Path('/tmp/milkup-p7-fold-tail-outline-1.3.4-02');ev=Path('/workspace/milkup-p7-fold-tail-evidence/external-1.3.4')
assert not out.exists();out.mkdir();ev.mkdir(exist_ok=True)
for name in ['src','scripts']:
 shutil.copytree(repo/'plugins/outline'/name,out/name)
for name in ['README.md','package.json','plugin.json','tsconfig.json']:
 shutil.copy2(repo/'plugins/outline'/name,out/name)
old=Path('/workspace/milkup-p7-quality-evidence/milestone02/outline/external-1.3.3/inputs')
for name in ['tsconfig.tests.json','vitest.config.mjs']:
 shutil.copy2(old/name,out/name)
(out/'vendor').mkdir();archive=old/'vendor/plugin-sdk-0.3.7.tgz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='58973ba8b0db0dd062be5612d4c3058e339205275ebee45f2b31395e5ec965b0'
shutil.copy2(archive,out/'vendor'/archive.name)
source=repo/'node_modules/.pnpm';dest=out/'node_modules/.pnpm';dest.mkdir(parents=True)
pending=[];seen=set();versions={}
for name in ['esbuild','typescript','vitest']:
 target=(repo/'node_modules'/name).resolve();relative=target.relative_to(source);pending.append(relative.parts[0]);(out/'node_modules'/name).symlink_to(Path('.pnpm')/relative)
 versions[name]=json.loads((target/'package.json').read_text())['version']
while pending:
 group=pending.pop()
 if group in seen:continue
 seen.add(group);src=source/group;dst=dest/group
 shutil.copytree(src,dst,symlinks=True,copy_function=shutil.copy2)
 for parent,dirs,files in os.walk(src,followlinks=False):
  for name in dirs+files:
   link=Path(parent)/name
   if not link.is_symlink():continue
   target=link.resolve(strict=True);rel=target.relative_to(source)
   pending.append(rel.parts[0])
   copied=out/'node_modules/.pnpm'/link.relative_to(source)
   copied.unlink();copied.symlink_to(os.path.relpath(dest/rel,copied.parent),target_is_directory=target.is_dir())
sdk=out/'node_modules/@milkup/plugin-sdk';sdk.mkdir(parents=True)
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  path=Path(member.name);assert path.parts[0]=='package' and '..' not in path.parts and not path.is_absolute()
  if member.isdir():continue
  assert member.isfile();p=sdk/Path(*path.parts[1:]);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(member).read())
for parent,dirs,files in os.walk(out/'node_modules',followlinks=False):
 for name in dirs+files:
  p=Path(parent)/name
  if p.is_symlink(): assert p.resolve(strict=True).is_relative_to(out)
p=out/'package.json';manifest=json.loads(p.read_text());manifest['devDependencies']={'@milkup/plugin-sdk':'file:vendor/plugin-sdk-0.3.7.tgz',**versions};manifest['packageManager']='pnpm@11.7.0';p.write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copytree(out,ev/'inputs',ignore=shutil.ignore_patterns('node_modules','dist'))
proof={'root':str(out),'sourceHead':os.popen('git -C /workspace/milkup rev-parse HEAD').read().strip(),'policy':'No install/network/dependency changes. Existing immutable tool closure copied; copied plugin sources; public SDK 0.3.7 extracted from verified retained tar. All symlinks resolve within external root. Source manifest legacy/non-frozen boundary retained.','tools':versions,'packageGroups':sorted(seen),'sdkTarSha256':hashlib.sha256(archive.read_bytes()).hexdigest()};(ev/'preparation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'root':str(out),'tools':versions,'packageGroups':len(seen)}))
