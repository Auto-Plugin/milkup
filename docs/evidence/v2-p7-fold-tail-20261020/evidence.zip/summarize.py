from pathlib import Path
import json, math, statistics
r=Path(__file__).resolve().parent
out={'primarySequence':['baseline-01','baseline-02','baseline-03','fix-01','fix-02','fix-03'],'crossoverSequence':['baseline-04','fix-04','fix-05','baseline-05'],'budgets':{'collapse':250,'expand':250,'editor-cursor-follow':200,'outline-click':200,'wheel-burst-10':200},'runs':[]}
for group in ['baseline','fix']:
 for i in range(1,6):
  name=f'{group}-{i:02}'; p=r/'native'/('p7-tail-'+name)
  completion=json.loads((p/'completion.json').read_text()); data=json.loads((p/'measurements.json').read_text())
  assert completion['passed'] and len(data)==106 and all(x['status']=='observed' for x in data)
  assert completion['sourceSha256']==completion['finalSourceSha256']=='997d1c7361e2a53082a935070c6f4f38b9668235744fdde5b16b8257c7d2d757'
  row={'run':name,'cohort':'primary' if i<=3 else 'crossover','functionalPassed':True,'operations':{}}
  for op,budget in out['budgets'].items():
   values=[x['elapsedMs'] for x in data if x['name'].startswith(op+'-') and x['name'][len(op)+1:].isdigit()]
   assert len(values)==20
   v=sorted(values);p95=v[math.ceil(.95*len(v))-1]
   row['operations'][op]={'n':20,'min':min(v),'median':statistics.median(v),'p95':p95,'max':max(v),'overBudget':sum(x>budget for x in v),'within100ms':sum(x<=100 for x in v),'p95BudgetPassed':p95<=budget,'samples':values}
  row['allWarmBudgetsPassed']=all(x['p95BudgetPassed'] for x in row['operations'].values())
  row['indexSamplesMs']=[x['elapsedMs'] for x in data if x['name'].startswith('index-')]
  row['indexFirstRowsMs']=[x['firstRowsMs'] for x in data if x['name'].startswith('index-')]
  out['runs'].append(row)
out['candidateStable250msProven']=all(row['operations']['collapse']['p95BudgetPassed'] for row in out['runs'] if row['run'].startswith('fix'))
out['candidateAllWarmBudgetsProven']=all(row['allWarmBudgetsPassed'] for row in out['runs'] if row['run'].startswith('fix'))
(r/'all-production-results.json').write_text(json.dumps(out,indent=2)+'\n')
for row in out['runs']:
 print(row['run'],{op:round(stats['p95']) for op,stats in row['operations'].items()},'collapse max',round(row['operations']['collapse']['max']))
