from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent
out=Path('/workspace/milkup/docs/evidence/v2-p7-fold-tail-20261020')
assert not (out/'evidence.zip').exists(), 'Never overwrite a frozen archive'
assert (root/'checks/lint-full02.exit').read_text().strip()=='0'
assert len(json.loads((root/'functional-results02.json').read_text()))==6

def excluded(p):
 return p.name=='milkup-desktop' or p.suffix.lower() in {'.milkup-plugin','.tgz','.exe','.msi','.msix','.dll','.deb','.pyc'} or p.relative_to(root).as_posix()=='external-1.3.4/plugin.js' or any(x in p.parts for x in ['node_modules','__pycache__','dist'])

def sha(data):return hashlib.sha256(data).hexdigest()
exclusions=[]
for p in sorted(root.rglob('*')):
 if p.is_file() and excluded(p):
  data=p.read_bytes();exclusions.append({'path':p.relative_to(root).as_posix(),'bytes':len(data),'sha256':sha(data),'reason':'Local build/dependency/distribution artifact excluded from uploaded evidence'})
(root/'excluded-artifacts.json').write_text(json.dumps(exclusions,indent=2)+'\n')
rows=[]
with zipfile.ZipFile(out/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or excluded(p):continue
  name=p.relative_to(root).as_posix();data=p.read_bytes();assert not data.startswith(b'\x7fELF')
  z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
data=(out/'evidence.zip').read_bytes()
index={'archive':'evidence.zip','archiveBytes':len(data),'archiveSha256':sha(data),'baseline':'cf7d407dbb9416232d4f2163e8cebf9d49798c57','source':'8f1645cd72522c10de6714b9918d6f0dc5baee38','performanceBudgetVerdict':'OPEN; candidate primary collapse p95 199/223/307ms; no stable end-to-end speedup proven','performanceRuns':10,'observations':1060,'successfulFunctionalRuns':6,'members':rows,'screenshots':json.loads((root/'pixel-review.json').read_text())['screenshots']}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
readme=f'''# P7 稀疏折叠检查点证据

精确基线 `cf7d407dbb9416232d4f2163e8cebf9d49798c57`，源码 `8f1645cd72522c10de6714b9918d6f0dc5baee38`。完整结论见[报告](../../v2-product-phase7-fold-tail-2026-10-20.md)。

**原性能预算仍未关闭。** 确定性读取等待从 8 轮降至 ≤5，不能替代原生延迟证明。主测候选折叠 p95 为 199/223/307 ms，第三轮失败；补充交叉对照不能覆盖主测。归档保留全部十轮、1060 条观察、原始分布、六组成功功能运行和功能脚本初轮失败，以及诊断、独立包、生产构建、全仓检查、实际 PNG 与清理证明。

[evidence.zip](evidence.zip)：{len(data):,} 字节，{len(rows)} 个成员，SHA256 `{sha(data)}`。逐成员大小及 SHA 见 [index.json](index.json)。

运行离线完整性校验：

```sh
python3 docs/evidence/v2-p7-fold-tail-20261020/verify.py
```

校验器核对原始脚本、完整夹具、样本数、逐轮 p95 与失败状态、源 Git blob、GitHub 身份、功能选区/保存、构建输入和进程清理。校验成功代表证据自洽，**不代表性能预算通过**。副本截图与 ZIP 原图逐字节一致。

ELF、安装器、`.milkup-plugin` 和依赖 tarball 不在归档内；本地构建物的哈希留在 `excluded-artifacts.json`、构建证明和外部构建证明。没有安装器上传、Release 或分支合并。没有 Windows/macOS GUI、真实 IME、读屏、系统 DPI 或完整主题/缩放矩阵的新增验证。
'''
(out/'README.md').write_text(readme)
print(json.dumps({'archiveBytes':len(data),'members':len(rows),'sha256':sha(data),'excluded':len(exclusions)}))
