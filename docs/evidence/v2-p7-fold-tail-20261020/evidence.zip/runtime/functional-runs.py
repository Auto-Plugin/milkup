import subprocess, json, datetime, os
from pathlib import Path
r=Path('/workspace/milkup-p7-fold-tail-evidence')
script=r/'runtime/driver-control.py'
candidate=r/'candidate-fix01/milkup-desktop'
sha='cdcf7cc535eaf31683c780d712f426e2940034fe5ed3ffaaec60adddaaa9a49b'
cases=[('dense-selection-02','dense','keyboard','run-functional.sh','source'),('large-lifecycle-01','large','lifecycle','run-fix.sh','source'),('ordinary-smoke-01','ordinary','smoke','run-fix.sh','source'),('ordinary-selection-01','ordinary','keyboard','run-functional.sh','source'),('ordinary-live-selection-01','ordinary','keyboard','run-functional.sh','live'),('dense-live-selection-01','dense','keyboard','run-functional.sh','live')]
results=[]
for name,fixture,phase,runner,mode in cases:
 run='p7-tail-'+name
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 subprocess.run(['python3',str(script),'start',run,str(candidate),sha],check=True)
 try:
  with (r/'logs'/f'{run}-harness.log').open('x') as log:
   p=subprocess.run(['bash',str(r/'runtime'/runner),run,'candidate-fix01',fixture,phase],stdout=log,stderr=subprocess.STDOUT,timeout=360,env={**os.environ,'MILKUP_P7_FUNCTIONAL_MODE':mode})
  (r/'logs'/f'{run}-harness.exit').write_text(str(p.returncode)+'\n')
  result={'run':run,'fixture':fixture,'phase':phase,'runner':runner,'mode':mode,'startedUtc':started,'exitCode':p.returncode,'completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  results.append(result)
  (r/'functional-results02.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(result),flush=True)
 finally:
  subprocess.run(['python3',str(script),'stop',run],check=True)
 if p.returncode: raise SystemExit(p.returncode)
