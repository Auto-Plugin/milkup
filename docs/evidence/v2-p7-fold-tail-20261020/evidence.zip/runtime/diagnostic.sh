#!/usr/bin/env bash
set -euo pipefail
[[ $# == 4 && "$1" =~ ^p7-tail-[a-z0-9-]+$ && "$2" =~ ^candidate-[a-z0-9-]+$ && "$3" =~ ^(ordinary|large|dense)$ && "$4" =~ ^(performance|keyboard|lifecycle|smoke)$ ]]
tail_candidate=/workspace/milkup-p7-fold-tail-evidence/$2
milkup_binary_sha=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["artifact"]["sha256"])' "$tail_candidate/proof.json")
source /workspace/milkup-p7-fold-tail-evidence/runtime/run-env.sh "$1" "$tail_candidate/milkup-desktop" "$milkup_binary_sha"
export MILKUP_PLUGIN_ARCHIVE=/workspace/milkup-p7-quality-evidence/milestone02/outline/external-1.3.3/milkup.outline-1.3.3.milkup-plugin
export MILKUP_PLUGIN_ARCHIVE_SHA256=80a9ce947c4abf2998eb72c36c327d5d826f0d30fa22dad61f903ff4713ca5c6
export MILKUP_P7_OUTLINE_VERSION=1.3.3 MILKUP_P7_OUTLINE_CASE="$3" MILKUP_P7_OUTLINE_PHASE="$4"
export MILKUP_P7_OUTLINE_INDEX_SAMPLES=1 MILKUP_P7_OUTLINE_SAMPLES=20 MILKUP_P7_BINARY_CONFIRMED=1
export MILKUP_P7_DIAGNOSTIC_SOURCE=/workspace/milkup-p7-fold-tail-evidence/native/p7-tail-baseline-01/outline.md
cd /workspace/milkup
exec node /workspace/milkup-p7-fold-tail-evidence/diagnostic-inputs/tests/native/tauri-p7-outline-diagnostic.mjs
