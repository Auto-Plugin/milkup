#!/usr/bin/env bash
set -euo pipefail
[[ $# == 4 && "$1" =~ ^p7-tail-[a-z0-9-]+$ && "$2" =~ ^candidate-[a-z0-9-]+$ && "$3" =~ ^(ordinary|large|dense)$ && "$4" =~ ^(performance|keyboard|lifecycle|smoke)$ ]]
tail_candidate=/workspace/milkup-p7-fold-tail-evidence/$2
milkup_binary_sha=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["artifact"]["sha256"])' "$tail_candidate/proof.json")
source /workspace/milkup-p7-fold-tail-evidence/runtime/run-env.sh "$1" "$tail_candidate/milkup-desktop" "$milkup_binary_sha"
export MILKUP_PLUGIN_ARCHIVE=/workspace/milkup-p7-fold-tail-evidence/external-1.3.4/milkup.outline-1.3.4.milkup-plugin
export MILKUP_PLUGIN_ARCHIVE_SHA256=ff6c1304ad3dd3c3b701a7232d69bb96d55962b9191a6e1a3162ee2aff2b2235
export MILKUP_P7_OUTLINE_VERSION=1.3.4 MILKUP_P7_OUTLINE_CASE="$3" MILKUP_P7_OUTLINE_PHASE="$4"
export MILKUP_P7_OUTLINE_INDEX_SAMPLES=3 MILKUP_P7_OUTLINE_SAMPLES=20 MILKUP_P7_BINARY_CONFIRMED=1
cd /workspace/milkup
exec node /workspace/milkup-p7-fold-tail-evidence/functional-inputs/tests/native/tauri-p7-outline-functional.mjs
