#!/usr/bin/env bash
set -euo pipefail
cd /tmp/milkup-p7-fold-tail-outline-1.3.4-02
node node_modules/typescript/bin/tsc --noEmit
node node_modules/typescript/bin/tsc --noEmit -p tsconfig.tests.json
node node_modules/vitest/vitest.mjs run --config vitest.config.mjs --maxWorkers=1
node scripts/build.mjs
