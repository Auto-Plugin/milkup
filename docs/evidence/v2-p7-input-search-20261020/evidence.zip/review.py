from pathlib import Path
import json,hashlib,math
from PIL import Image
root=Path(__file__).parent;native=root/'native'
def digest(data):return hashlib.sha256(data).hexdigest()
def stat(values):
 values=sorted(values);return {'n':len(values),'min':min(values),'median':(values[(len(values)-1)//2]+values[len(values)//2])/2,'p95':values[math.ceil(.95*len(values))-1],'max':max(values),'within100':sum(v<=100 for v in values)}
rows=[]
for p in sorted(native.glob('p7-input-large-*/samples.json')):
 d=json.loads(p.read_text());assert d['complete'];original=(p.parent/'original.md').read_bytes();assert digest(original)==d['metadata']['sha256']
 history=json.loads((p.parent/'history.json').read_text());assert [v['label'] for v in history]==['replace-selection','undo','redo','restore-original']
 changed='中e\u0301👩🏽‍💻'.encode()+original[1:]
 assert [v['sha256'] for v in history]==[digest(changed),digest(original),digest(changed),digest(original)]
 assert all(not v['state']['dirty'] and not v['state']['saving'] and v['state']['version']==v['state']['savedVersion'] for v in history)
 diag=json.loads((p.parent/'diagnostics.json').read_text());assert diag['backend'];timed=[s for s in d['samples'] if 'frameMs' in s];assert all(s['trusted'] for s in timed)
 search=[s for s in timed if s['kind']=='search'];assert len(search)==1 and search[0]['count']=='1/1' and search[0]['cursor']==1
 search=search[0]; groups={k:stat([s['frameMs'] for s in timed if s['kind']==k and s.get('temperature')!='first-target']) for k in ['input','delete','jump']}
 rows.append({'run':p.parent.name,'mode':d['metadata']['mode'],'metadata':d['metadata'],'samples':len(d['samples']),'timedSamples':len(timed),'groups':groups,'search':{k:search[k] for k in ['domMs','frameMs','targetMs','overTarget']},'searchDOMToFramesMs':search['frameMs']-search['domMs'],'searchFrameGaps':[g for g in diag['frameGaps'] if search['started']-100<=g['at']<=search['twoFrames']+100],'individualOverTarget':d['violations'],'historyChecks':4,'originalSHA256':digest(original),'functionalPassed':True,'groupPerformancePassed':all(g['p95']<=200 for g in groups.values()),'searchPassed':search['frameMs']<=500})
assert len(rows)==6 and sum(r['samples'] for r in rows)==858
cold=[]
for run,prior in [('p7-input-cold-html-02','p6-cold-html-02'),('p7-input-cold-a4-01','p6-cold-a4-01'),('p7-input-cold-print-01','p6-cold-print-02')]:
 current=native/run;old=Path('/workspace/milkup-plugin-lifecycle-evidence/milestone01/native-ui/runs')/prior
 assert json.loads((current/'completion.json').read_text())['automatedChecksPassed']
 record={'run':run,'prior':prior,'sourceSHA256':digest((current/'source.md').read_bytes())}
 if 'html' in run:
  a=(current/'cold-first.html').read_bytes();b=(old/'cold-first.html').read_bytes();assert a==b;assert b'[^p5]' not in a;record.update(htmlByteIdentical=True,sha256=digest(a))
 else:
  pages=[]
  for p in sorted(current.glob('cold-first.pdf.page-*.png')):
   a=Image.open(p).convert('RGB');b=Image.open(old/p.name).convert('RGB');assert a.size==b.size and a.tobytes()==b.tobytes()
   pages.append({'file':p.name,'rgbSHA256':digest(a.tobytes()),'priorRGBSHA256':digest(b.tobytes()),'dimensions':list(a.size)})
  assert len(pages)==7;record.update(allPagesPixelIdentical=True,pages=pages,pdfSHA256=digest((current/'cold-first.pdf').read_bytes()))
 cold.append(record)
result={'sourceHead':'cf7d407dbb9416232d4f2163e8cebf9d49798c57','coldReadinessPassed':True,'cold':cold,'runs':rows,'functionalPassed':True,'historyChecks':24,'samples':858,'timedSamples':sum(r['timedSamples'] for r in rows),'performancePassed':all(r['groupPerformancePassed'] and r['searchPassed'] for r in rows),'firstSearchFailures':sum(not r['searchPassed'] for r in rows),'individualBudgetViolations':sum(len(r['individualOverTarget']) for r in rows),'scope':'Six fresh process/profile runs, first query after 20 reversible edit cycles and save, not cold OS caches; X11 clipboard is not IME; two rAF is not physical presentation.'}
(root/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for r in rows:print(r['run'], {k:round(v['p95'],2) for k,v in r['groups'].items()},'search',r['search'],'history PASS')
print({k:result[k] for k in ['coldReadinessPassed','functionalPassed','historyChecks','samples','timedSamples','performancePassed','firstSearchFailures','individualBudgetViolations']})
