import subprocess,pathlib,json,datetime,hashlib,sys,shlex
root=pathlib.Path(__file__).resolve().parent.parent
runtime=root/'runtime';binary='/workspace/milkup-p7-fold-tail-evidence/candidate-baseline02/milkup-desktop';sha='f320d5dd7baf43996ef25c39fa239d041ce4d3704e874463bf04a7dca2f0aab7'
plan=[('p7-input-cold-a4-01','cold','pdf-a4'),('p7-input-cold-print-01','cold','print-to-file')]+[(f'p7-input-large-{mode}-{n:02d}','latency',mode) for n in range(1,4) for mode in ['source','live']]
(root/'preparation'/'bounded-run-plan.json').write_text(json.dumps({'runs':plan,'cycles':20,'fixtureBytesRequested':10485760,'lineBytes':64,'inputTargetMs':200,'firstSearchTargetMs':500,'firstSearchSamplesPerMode':3,'policy':'All failures retained. No OS cache flush. Cold-output first means first export in a new process/profile, not first renderer invocation. No outline performance tests.'},indent=2)+'\n')
for name,kind,option in plan:
 if sys.argv[1]=='cold' and kind!='cold':continue
 if sys.argv[1]=='first' and (kind!='latency' or not name.endswith('-01')):continue
 if sys.argv[1]=='remaining' and (kind!='latency' or name.endswith('-01')):continue
 record=root/'control'/(name+'-execution.json');assert not record.exists()
 row={'run':name,'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binarySha256':sha}
 try:
  subprocess.run(['python3',str(runtime/'driver-control.py'),'start',name,binary,sha],check=True)
  command='source '+shlex.quote(str(runtime/'run-env.sh'))+' '+shlex.join([name,binary,sha])+'\n'
  if kind=='cold':
   command+='source '+shlex.quote(str(runtime/'cold-env.sh'))+'\nexport MILKUP_P6_FORMAT='+shlex.quote(option)+'\nexec node '+shlex.quote(str(root/'cold-source/tests/native/tauri-p6-lifecycle.mjs'))
  else:
   command+='export MILKUP_LATENCY_BYTES=10485760 MILKUP_LATENCY_LINE_BYTES=64 MILKUP_LATENCY_CYCLES=20 MILKUP_LATENCY_HISTORY_CHECK=1 MILKUP_LATENCY_MODE='+shlex.quote(option)+'\nexec node tests/native/tauri-production-latency.mjs'
  row['command']=['bash','-c',command]
  with (root/'control'/(name+'-harness.log')).open('x') as log:
   result=subprocess.run(row['command'],cwd='/workspace/milkup',stdout=log,stderr=subprocess.STDOUT,timeout=300)
  row['exitCode']=result.returncode
 except Exception as e:row['error']=str(e)
 finally:
  subprocess.run(['python3',str(runtime/'driver-control.py'),'stop',name],check=True)
  row['endedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record.write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 if row.get('exitCode')!=0:break
