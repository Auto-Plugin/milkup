"""Keep performance failure separate from completed UI/functional runs."""
from pathlib import Path
import json,sys
root=Path(__file__).parent
review=json.loads((root/'review.json').read_text())
assert review['coldReadinessPassed'] and review['functionalPassed']
assert review['historyChecks']==24 and review['samples']==858
failures=[{'run':r['run'],'search':r['search']} for r in review['runs'] if not r['searchPassed']]
assert len(failures)==review['firstSearchFailures']
result={'passed':review['performancePassed'],'firstSearchFailures':failures,'individualBudgetViolations':review['individualBudgetViolations'],'functionalPassed':True,'coldReadinessPassed':True}
(root/'quality-gate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'performancePassed':result['passed'],'firstSearchFailures':len(failures),'functionalPassed':True,'coldReadinessPassed':True}))
sys.exit(0 if result['passed'] else 1)
