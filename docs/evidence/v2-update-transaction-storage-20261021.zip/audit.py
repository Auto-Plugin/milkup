from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/workspace/milkup')
out = Path('/workspace/milkup-update-transaction-store-evidence')
baseline = '3166d4eb38839fea41b8b47e16633ea88732ceef'
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
def sha(data):
    return hashlib.sha256(data).hexdigest()

sources = [
    'apps/desktop/src-tauri/src/update_transaction.rs',
    'apps/desktop/src-tauri/src/update_transaction_tests.rs',
    'apps/desktop/src-tauri/src/update_policy.rs',
    'apps/desktop/src-tauri/src/updates.rs',
]
hashes = {}
for name in sources:
    data = (root / name).read_bytes()
    (out / Path(name).name).write_bytes(data)
    hashes[name] = sha(data)

# Reverse only the documented helper extraction/wrapper to prove that the
# original trust policy, including its file access behavior, is unchanged.
policy_name = sources[2]
old_policy = git('show', f'{baseline}:{policy_name}').decode()
new_policy = (root / policy_name).read_text()
start = old_policy.index('        // Account-owner mutation')
end = old_policy.index('        let lock = open_regular', start)
old_check = old_policy[start:end]
reconstructed = new_policy.replace('        check_private_directory(&self.directory)?;\n', old_check, 1)
start = reconstructed.index('// Shared only inside the native update module.')
end = reconstructed.index('    let mut options = OpenOptions::new();', start)
reconstructed = (reconstructed[:start] +
    'fn open_regular(path: &Path, create: bool, exclusive: bool) -> Result<File, String> {\n' +
    reconstructed[end:])
reconstructed = reconstructed.replace('.write(write)', '.write(create)', 1)
assert reconstructed == old_policy, 'trust policy behavior unexpectedly changed'

updates_name = sources[3]
updates = (root / updates_name).read_text()
declaration = '''// Normally compiled native storage, intentionally not wired to installation,
// startup, IPC or plugins until a trusted handoff protocol is implemented.
#[allow(dead_code)]
#[path = "update_transaction.rs"]
mod transaction;

'''
assert updates.replace(declaration, '', 1) == git('show', f'{baseline}:{updates_name}').decode()

unchanged = [
    'apps/desktop/src-tauri/src/lib.rs',
    'apps/desktop/src-tauri/src/update_pe.rs',
    'apps/desktop/src-tauri/Cargo.toml',
    'apps/desktop/src-tauri/Cargo.lock',
    'apps/desktop/src-tauri/tauri.conf.json',
    'apps/desktop/src-tauri/nsis-hooks.nsh',
    'vendor/tauri-plugin-updater',
    '.github/workflows',
    'packages',
    'apps/desktop/src',
    'plugins',
    'release',
    'pnpm-lock.yaml',
]
for path in unchanged:
    assert (root / path).exists(), path
    assert not git('diff', baseline, '--', path), path
dep = (root / 'apps/desktop/src-tauri/target/debug/libmilkup_desktop_lib.d').read_bytes()
assert b'/update_transaction.rs' in dep
assert b'/update_transaction_tests.rs' not in dep
assert b'/update_health_contract.rs' not in dep
(out / 'normal-library-dependencies.d').write_bytes(dep)
artifact = root / 'apps/desktop/src-tauri/target/debug/libmilkup_desktop_lib.rlib'
full = (out / 'full-rust-tests.log').read_text()
assert '228 passed; 0 failed; 5 ignored' in full
assert full.count('KILL/REOPEN ') == 3
assert 'Finished `dev` profile' in (out / 'normal-build.log').read_text()
result = {
    'baseline': baseline,
    'branch': git('branch', '--show-current').decode().strip(),
    'sources_sha256': hashes,
    'original_trust_policy_reconstructed_identically': True,
    'updates_unchanged_except_private_module_declaration': True,
    'unchanged_paths': unchanged,
    'normally_compiled_module_in_dependency_file': True,
    'test_module_and_prior_model_excluded_from_normal_dependency_file': True,
    'normal_library': {'bytes': artifact.stat().st_size, 'sha256': sha(artifact.read_bytes()),
        'not_in_evidence_archive': True},
    'rust_tests': {'passed': 228, 'failed': 0, 'existing_ignored': 5},
    'real_process_test': {'killed_owned_children': 3, 'contention_children': 3,
        'power_loss_test': False},
    'production_integration': False,
    'windows_executed_this_checkpoint': False,
}
(out / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(out / 'shared-helper-and-module.diff').write_bytes(git('diff', baseline, '--', policy_name, updates_name))
print(json.dumps(result, ensure_ascii=False, indent=2))
