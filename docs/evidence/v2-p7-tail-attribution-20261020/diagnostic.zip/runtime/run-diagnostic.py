from pathlib import Path
import datetime,json,os,subprocess,threading,time
r=Path('/workspace/milkup-p7-tail-attribution-evidence');run='p7-tail-attribution-01';control=r/'runtime/driver-control.py'
binary='/workspace/milkup-p7-fold-tail-evidence/candidate-fix01/milkup-desktop';sha='cdcf7cc535eaf31683c780d712f426e2940034fe5ed3ffaaec60adddaaa9a49b'
subprocess.run(['python3',str(control),'start',run,binary,sha],check=True)
owner=json.loads((r/'control'/f'{run}-driver.json').read_text());stop=threading.Event();samples=[];errors=[];tracked={};overhead=[]
def read(path):
 try:return Path(path).read_text()
 except OSError:return None
def sample():
 begin=time.perf_counter_ns();stats={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  raw=read(p/'stat')
  if not raw:continue
  try:
   parts=raw[raw.rfind(')')+2:].split();pid=int(p.name)
   stats[pid]={'pid':pid,'comm':raw[raw.find('(')+1:raw.rfind(')')],'state':parts[0],'ppid':int(parts[1]),'pgid':int(parts[2]),'utimeTicks':int(parts[11]),'stimeTicks':int(parts[12]),'startTicks':int(parts[19]),'rssPages':int(parts[21])}
  except (ValueError,IndexError):continue
 included={pid for pid,s in stats.items() if s['pgid']==owner['pgid'] or tracked.get(pid)==s['startTicks']}
 for _ in range(20):
  more={pid for pid,s in stats.items() if s['ppid'] in included}
  if more.issubset(included):break
  included.update(more)
 for pid in included:
  if len(tracked)<512:tracked[pid]=stats[pid]['startTicks']
 row={'wallMs':time.time_ns()/1e6,'monotonicNs':time.monotonic_ns(),'cgroupCpuStat':read('/sys/fs/cgroup/cpu.stat'),'cgroupCpuPressure':read('/sys/fs/cgroup/cpu.pressure'),'systemCpuPressure':read('/proc/pressure/cpu'),'systemCpuStat':(read('/proc/stat') or '').splitlines()[0],'processes':[stats[p] for p in sorted(included)][:512]}
 row['sampleCostMs']=(time.perf_counter_ns()-begin)/1e6;samples.append(row);overhead.append(row['sampleCostMs'])
def sampling():
 while len(samples)<300 and not stop.is_set():
  try:sample()
  except Exception as error:errors.append(str(error))
  stop.wait(1)
thread=threading.Thread(target=sampling,daemon=True);thread.start();started=datetime.datetime.now(datetime.timezone.utc).isoformat();code=None
try:
 with (r/'logs'/f'{run}-harness.log').open('x') as log:
  result=subprocess.run(['bash',str(r/'runtime/diagnostic.sh'),run,'candidate-fix01','dense','performance'],stdout=log,stderr=subprocess.STDOUT,timeout=300)
 code=result.returncode
 (r/'logs'/f'{run}-harness.exit').write_text(str(code)+'\n')
finally:
 stop.set();thread.join(3)
 (r/'system-samples.json').write_text(json.dumps({'startedUtc':started,'endedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'intervalSeconds':1,'limit':300,'clockTicksPerSecond':os.sysconf('SC_CLK_TCK'),'pageSize':os.sysconf('SC_PAGE_SIZE'),'sampleCount':len(samples),'observerMs':sum(overhead),'maxSampleMs':max(overhead,default=0),'errors':errors,'samples':samples},indent=2)+'\n')
 subprocess.run(['python3',str(control),'stop',run],check=True)
print(json.dumps({'exitCode':code,'samples':len(samples),'samplerCostMs':sum(overhead)}))
raise SystemExit(code if code is not None else 1)
