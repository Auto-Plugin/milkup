import pathlib,json,subprocess,hashlib
import fitz
from pypdf import PdfReader
root=pathlib.Path(__file__).parent
results={}
queries=['LINK-CHECKPOINT-ASCII','SERIALIZED-CHECKPOINT','FORWARD-ID','FORWARD-NAME','EXTERNAL-HTTPS','BACK-ID','FOOTNOTE-TARGET','FOOTNOTE-DEFINITION','中文搜索','café','cafe\u0301','Ω','Ω','Å','Å','office','ﬁle']
for name in ['minimal','serialized']:
 file=root/(name+'.pdf');doc=fitz.open(file); reader=PdfReader(file)
 subprocess.run(['pdftotext','-layout',str(file),str(root/(name+'-poppler.txt'))],check=True)
 text='\n'.join(p.get_text() for p in doc);(root/(name+'-mupdf.txt')).write_text(text)
 poppler=(root/(name+'-poppler.txt')).read_text()
 pages=[]
 for i,page in enumerate(doc):
  png=root/(name+f'-page-{i+1}.png');page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(png)
  pages.append({'page':i+1,'size':list(page.rect),'links':page.get_links(),'annots':len(reader.pages[i].get('/Annots',[])),'image':png.name,'imageSha256':hashlib.sha256(png.read_bytes()).hexdigest()})
 results[name]={'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'metadata':doc.metadata,'pages':pages,'namedDestinations':list(reader.named_destinations),'queries':{q:{'codepoints':['U+%04X'%ord(c) for c in q],'mupdfExactSubstring':q in text,'popplerExactSubstring':q in poppler,'mupdfSearchHits':sum(len(p.search_for(q)) for p in doc)} for q in queries}}
(root/'audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for name,result in results.items():
 print(name,'pages',len(result['pages']),'links',sum(len(p['links']) for p in result['pages']),'annots',sum(p['annots'] for p in result['pages']),'destinations',len(result['namedDestinations']),'producer',result['metadata']['producer'])
 print((root/(name+'-poppler.txt')).read_text())
