# SERIALIZED-CHECKPOINT

Reference[^a]

[EXTERNAL-HTTPS](https://example.com/p5-checkpoint)

UNICODE: 中文搜索 café café Ω Ω Å Å office ﬁle

[^a]: FOOTNOTE-DEFINITION