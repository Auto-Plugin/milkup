#!/usr/bin/env bash
set -euo pipefail
# Same private user/mount namespace as production08. GTK print modules are
# mapped read-only alongside WebKit; neither system nor sandbox is modified.
exec bwrap --unshare-user --ro-bind / / --bind /workspace /workspace --bind /tmp /tmp --dev-bind /dev /dev --proc /proc --overlay-src /usr/bin --tmp-overlay /usr/bin --ro-bind /workspace/.cloud/milkup-v2/sysroot/usr/bin/xdg-dbus-proxy /usr/bin/xdg-dbus-proxy --remount-ro /usr/bin --overlay-src /usr/lib/x86_64-linux-gnu --tmp-overlay /usr/lib/x86_64-linux-gnu --ro-bind /workspace/.cloud/milkup-v2/sysroot/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1 /usr/lib/x86_64-linux-gnu/webkit2gtk-4.1 --ro-bind /workspace/.cloud/milkup-v2/sysroot/usr/lib/x86_64-linux-gnu/gtk-3.0 /usr/lib/x86_64-linux-gnu/gtk-3.0 --remount-ro /usr/lib/x86_64-linux-gnu -- "$@"
