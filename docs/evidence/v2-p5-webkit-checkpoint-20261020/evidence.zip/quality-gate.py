"""Actual PDF quality gate. Baseline is expected to exit 1, never relabelled PASS."""
from pathlib import Path
import json, sys
root = Path(__file__).parent
report = json.loads((root / 'audit.json').read_text())
failures = []
for name, expected in [('minimal', 4), ('serialized', 3)]:
    actual = sum(len(page['links']) for page in report[name]['pages'])
    if actual < expected:
        failures.append({'case': name, 'requirement': 'actionable PDF links', 'expectedMinimum': expected, 'actual': actual})
    for query in ['中文搜索', 'cafe\u0301', 'office']:
        result = report[name]['queries'][query]
        if not result['popplerExactSubstring'] or not result['mupdfExactSubstring'] or result['mupdfSearchHits'] == 0:
            failures.append({'case': name, 'requirement': 'exact source text and search', 'query': query, 'actual': result})
    positive = report[name]['queries']['EXTERNAL-HTTPS']
    assert positive['popplerExactSubstring'] and positive['mupdfExactSubstring'] and positive['mupdfSearchHits'] == 1, 'ASCII search positive control failed'
result = {'passed': not failures, 'failures': failures, 'positiveControlPassed': True, 'viewerNote': 'MuPDF search_for, not manual GUI search or clipboard; raw Poppler and MuPDF extraction.'}
(root / 'quality-gate.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'failures': len(failures), 'positiveControlPassed': True}))
sys.exit(1 if failures else 0)
