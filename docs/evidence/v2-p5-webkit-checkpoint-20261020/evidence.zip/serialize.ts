import { writeFileSync } from 'node:fs'
import { renderStaticMarkdownDocument as render } from '/workspace/milkup/packages/export/src/static-html.ts'
const root = '/workspace/milkup-p5-webkit-checkpoint-evidence'
const source = '# SERIALIZED-CHECKPOINT\n\nReference[^a]\n\n[EXTERNAL-HTTPS](https://example.com/p5-checkpoint)\n\nUNICODE: 中文搜索 café café Ω Ω Å Å office ﬁle\n\n[^a]: FOOTNOTE-DEFINITION'
const options = {documentId: 'doc', version: 1}
const start = source.indexOf('[^a]'), definition = source.lastIndexOf('[^a]')
const ref = (label: string, from: number, to: number) => ({type: 'reference' as const, label, target: {...options, from, to}})
const fragments = [
 {from: start, to: start+4, layout: 'inline' as const, accessibleText: '1', content: {type: 'sup' as const, children: [ref('1', definition, source.length)]}},
 {from: definition, to: definition+5, layout: 'inline' as const, accessibleText: 'back', content: {type: 'group' as const, children: [{type: 'text' as const, text: '[1] '}, ref('BACK-ID',start,start+4)]}},
]
const result = render(source, {...options, title: 'P5 serialized footnote control', pageSize: 'a4', presentations: [{
 request: {...options, source, from: 0, to: source.length, fromLine: 1, toLine: source.split('\n').length, completeStart: true, completeEnd: true, contextKnown: true, protectedRanges: [], blocks: [{kind: 'text', complete: true, from: 0, to: source.length, contentRanges: [{from:0, to:source.length}]}], selection:{anchor:0,head:0}, theme:'light', target:'export', width:760},
 result: {complete: true, fragments}, declarations: [{id:'checkpoint',contexts:['text']}]
}]})
if(result.warnings.length) throw new Error(JSON.stringify(result.warnings))
for(const id of [start,definition]) if(!result.html.includes(`href="#source-${id}"`) || !result.html.includes(`id="source-${id}"`)) throw new Error('Missing valid paired anchor')
writeFileSync(root+'/serialized.md',source)
writeFileSync(root+'/serialized.html',result.html)
writeFileSync(root+'/serializer-proof.json',JSON.stringify({warnings:result.warnings,start,definition,validBidirectionalAnchors:true,note:'Current production serializer with a controlled public presentation batch; no live plugin invocation.'},null,2)+'\n')
