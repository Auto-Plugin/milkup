from pathlib import Path
import json,collections,sys
root=Path(sys.argv[1]); r=json.loads((root/'windows-w0-matrix.json').read_text())
def val(x):return x.get('result',{}).get('value')
rows=[]
previous=[]
for c in r['cases']:
 child=c.get('child',{}); all_events=c.get('endpointObservationsAtStop',[]); events=all_events[len(previous):];previous=all_events
 rows.append({
  'name':c['name'],'completed':c.get('completed'),'error':c.get('error'),'durationMs':c.get('observedDurationMs'),
  'token':c.get('suspendedToken'),'nativeNetwork':child.get('nativeNetwork'),'dns':child.get('explicitServerDns'),
  'apiResults':val(child.get('networkApiResults',{})),
  'receipts':dict(collections.Counter(f"{e['transport']}/{e.get('family','?')}" for e in events)),
  'turnUsernames':dict(collections.Counter(e.get('turnUsername') for e in events if e.get('turnUsername'))),
  'udpOwners':list({json.dumps(o,sort_keys=True):o for e in events for o in e.get('socketOwners',{}).get('owners',[])}.values()),
  'fileNavigations':child.get('fileNavigations'),'picker':val(child.get('pickerProbe',{})),'ownedDialogs':c.get('ownedPickerDialogs'),
  'directBreakaway':child.get('directBreakaway'),'ownerExitCode':c.get('ownerExitCode'),'activeAfterOwnerExitBeforeHostStop':c.get('activeAfterOwnerExitBeforeHostStop'),
  'intentionalDeadlineExpired':c.get('intentionalDeadlineExpired'),
  'accountingBeforeStop':c.get('accountingBeforeStop'),'accountingAfterStop':c.get('accountingAfterStop'),
  'sampledDistinctProcesses':c.get('sampledDistinctProcesses'),'allAccountedProcessesSampled':c.get('allAccountedProcessesSampled'),
  'completionMessages':dict(collections.Counter(str(e['message']) for e in c.get('jobCompletionEvents',[]))),
  'retainedHandlesAllSignaled':all(p['signaledAfterStop'] for p in c.get('retainedProcessHandles',[])),
  'sampledTokens':list({json.dumps(p['observation'].get('token'),sort_keys=True):p['observation'].get('token') for p in c.get('retainedProcessHandles',[])}.values()),
 })
summary={'source':r['source'],'cases':rows,'cleanup':{k:r.get(k) for k in ['cleanupErrors','outsideFileUnchanged','privateTreeAndAclRemoved','profileDeletedAndFolderAbsent']},'networkCanaryGatePassed':r.get('networkCanaryGatePassed'),'restrictedReceiptCount':len(r.get('receivedRestrictedCanaries',[])),'fullIsolationGatePassed':r['fullIsolationGatePassed'],'productIntegrated':r['productIntegrated']}
(root/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
