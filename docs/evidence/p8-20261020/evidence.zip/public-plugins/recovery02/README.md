# P8 public plugin recovery02

Baseline: `a4d44e680478d7894450f30f3d533dc1c3131974`.

- Rechecked the three exact LF attributes and platform-separator containment fix; validator hashes remain strict.
- Narrowed diagrams vendor ignore to `vendor/*` plus `!vendor/plugin-sdk.tgz`, retaining the existing 22,524-byte public SDK 0.3.4 archive. No download, repacking, new dependency, host SDK substitution, installation, whole-repo build or Rust run occurred here. Root owns Git staging and commit.
- Updated plugin README and added `SDK-PROVENANCE.md` with original archive/member hashes and historical public-source evidence. `sdk-provenance.json` records strict archive parsing, installed SDK equality, history comparisons, and unchanged baseline authority inputs.
- Historical public SDK source commit: `2c3ff12bf3caa50520c8b6d49601e2f33a5f7da0`. JavaScript, declarations and README match exactly. Parsed package metadata matches after resolving only `@milkup/core` from `workspace:*` to historical core version `2.0.0-beta.1`; raw JSON order/bytes differ and are not misrepresented as equal.
- Extended the existing real Git autocrlf fixture to include `.gitignore` and the actual reviewed SDK archive, assert it is staged while a different vendor archive remains ignored, verify its hash after checkout, and run strict SDK parsing/version/member checks. The unrelated text CRLF control remains mandatory.
- `focused-tests.log` / `focused-tests.json`: **38 pass, 0 fail, 0 skipped**, exit 0. This is the original five-suite 37-test coverage plus one SDK checkout hash subtest. Earlier `../green01.*` 37-pass and `../red01.*` failure evidence remain untouched.
- Scoped Prettier check and `git diff --check` pass. A first formatting check flagged only the newly written provenance Markdown table; it was formatted before the final check.

The missing Git input is resolved for root staging; the Windows/source agent was told the preserved SDK input is ready. Actual fresh-checkout eleven-plugin build and Windows execution are separate evidence, not claimed by these local tests.
