# CI02 SDK path-alias regression

CI02 (6353823365b7ee33a37cac3fd9c8be5374b4d711) really failed on Windows in `public-plugin-sdk-artifact.test.mjs`: the trusted resolver returned canonical `C:\Users\runneradmin\...`, while the test expected the input `C:\Users\RUNNER~1\...` spelling from os.tmpdir(). Both identify the same file. The original source-contract log is preserved in `ci02-source-check-contracts.log`; its source path/hash are recorded in `proof.json`. That log also retains the separately owned workflow/CRLF failure.

Only `tests/ci/public-plugin-sdk-artifact.test.mjs` changes. The expected SDK entry is resolved using actual filesystem `realpath` before strict comparison. The production returned path is still required to be canonical. No lowercasing, substring comparison, path suffix check, validator normalization or production-source change is introduced.

The new regression creates a real directory symlink on POSIX or junction on Windows, passes that alias through the production resolver, and checks both original and aliased spellings against the same canonical result. It requires lexical alias/result inequality, so an alias fixture cannot silently collapse into an ordinary path. It also rejects a wrong reviewed archive hash and altered installed bytes through the alias. Existing outside-installation, archive structure, metadata, all-member byte equality and wrong SDK tests remain intact.

- `alias-unnormalized-red.*`: same new suite with only the expected-path normalization removed, **7 pass / 1 fail**, exit1. This is a controlled regression variant, not a claim of rerunning Windows locally.
- `sdk-artifact-green.*`: actual changed suite, **8 pass / 0 fail / 0 skipped**, exit0.
- Scoped Prettier and `git diff --check`: pass.
- `proof.json` confirms `scripts/ci/public-plugin-build-contract.mjs` still equals HEAD byte for byte.

The actual Windows 8.3 failure remains historical CI02 evidence. This Linux run verifies real symlink alias behavior; Windows junction and native short/long temp-path behavior require the next Windows CI run. No workflow/schema/Rust changes, dependency installation, full-repository suite, commit or push performed here.
