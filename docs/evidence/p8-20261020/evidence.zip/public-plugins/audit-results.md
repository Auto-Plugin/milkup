# P8 public plugin / Windows source readiness audit

Baseline: `a4d44e680478d7894450f30f3d533dc1c3131974`, branch `dot/milkup-v2-product-phase8-readiness`. This is source inspection plus focused Linux-hosted Node/Git regression evidence. It does not constitute Windows desktop or eleven-plugin build acceptance.

## Two reproduced defects and narrow fixes

1. Git `core.autocrlf=true` converted three exact-hashed Mermaid closure inputs to CRLF: `pnpm-lock.yaml`, `build-dependencies.json`, and `THIRD-PARTY-NOTICES.txt`. `.gitattributes` now applies `text eol=lf` only to those three paths. No validator normalization or reviewed hash update was used. The regression creates a temporary Git index and actual checkout with autocrlf enabled; its unrelated text control must still become CRLF, then exact hashes and the real `readDependencyClosure` validator are checked.
2. The standalone diagrams helper rejected `../` but accepted Windows `..\` ancestor and same-prefix sibling escapes. `within` now rejects `..`, the platform-specific parent prefix, and absolute relative results. Tests execute the actual function body with Node's POSIX and Win32 path implementations, including UNC and cross-drive cases. This is path-semantics coverage, not a Windows filesystem run.

Only `.gitattributes`, `plugins/diagrams/scripts/build-support.mjs`, and two new `tests/ci/*` regression files were changed for these fixes. The dependency profile lists the helper as a build input path, without an individual helper content hash; its reviewed dependency bytes remain unchanged. Future copied-input proofs must capture the changed helper normally.

## Recorded validation

- `red01.log` / `red01.json`: new regressions against the old implementation, exit 1; Node reports 14 tests, 6 pass, **8 fail**. Failures comprise three Win32 path cases, three exact checkout hashes, the actual closure validator, and the checkout parent test counted by Node. Do not describe this as eight independent defects.
- `green01.log` / `green01.json`: both new files plus public SDK artifact, DOM build, and public build contract suites, **37 pass, 0 fail, 0 skipped**, exit 0. Commands and UTC start/end are in the JSON records.
- The changed JavaScript tests/helper were formatted and scoped `git diff --check` passed. No dependency install, whole-workspace check, archive generation, independent eleven-plugin build, or Windows runner was executed in this task.
- `input-proof01.json` preserves changed source/test fingerprints and exact authority inputs. The release inventory, lock, profile and notices equal their baseline Git bytes. The ignored vendor tar matches its reviewed profile hash; it is not falsely reported as Git-tracked.

| Reviewed input | SHA-256, unchanged |
| --- | --- |
| release inventory | `8b9e6bf8f968009dd95079028f68d5e920d5298b2b752bf2f8b6a1c7b24e34ea` |
| Mermaid lock | `eece5b86a0955df5204de2dc0cd69b1907a31a83de7d6fad39fa442c11ca7f01` |
| Mermaid profile | `286fc4ff7359ecca44941bad046b88e2b185150ae8cb01280c94b67830e10c10` |
| Mermaid notices | `4afc4a6bf7a01a621abaada6cda0ec9d1775a755b73f5954d951537d8ed24cb0` |
| Frozen public SDK 0.3.4 tar | `1717c0114aa165fa3e48a1bfa7687ffd0d9b2e5392d33e99d8b2dc59a1f3ad4f` |

## Public SDK and build closure

The current SDK is 0.3.7. Its public JavaScript/declaration entry has no native platform dependency. The reviewed inventory contains eleven preinstalled packages:

| Plugin | Version | Host | Declared SDK compatibility |
| --- | --- | --- | --- |
| outline | 1.3.3 | worker | >=0.2.0 <0.4.0 |
| updates | 1.0.0 | worker | >=0.2.0 <0.4.0 |
| workspace | 1.0.0 | worker | ^0.3.0 |
| preferences | 1.0.0 | worker | ^0.3.1 |
| shortcuts | 1.0.0 | worker | >=0.3.1 <0.4.0 |
| formatting | 1.0.0 | worker | >=0.3.2 <0.4.0 |
| images | 1.0.0 | worker | ^0.3.2 |
| math | 1.0.0 | worker | ^0.3.3 |
| diagrams | 1.1.1 | dom | >=0.3.4 <0.4.0 |
| footnotes | 1.0.1 | worker | >=0.3.6 <0.4.0 |
| management | 1.0.0 | worker | >=0.3.7 <0.4.0 |

Only diagrams has the frozen dependency profile, including the reviewed SDK 0.3.4 tar. The other ten are explicitly `legacy-non-frozen`; do not label all eleven dependency closures frozen. Export-print is independent and is not one of these eleven.

`verify-public-plugin-builds.mjs` copies inputs outside the checkout, packs the public SDK locally, builds/tests the ten legacy packages with that public tar, and preserves diagrams' frozen SDK/lock/profile. It does not run TypeScript checking itself; the proposed Windows caller must additionally typecheck each independent target. `public-plugin-build-contract.mjs` validates the frozen SDK's installed exports against the reviewed tar, rather than forcing its version to equal the current host SDK. This must remain intact.

A root workspace install alone does not restore standalone diagrams dependencies because `plugins/**` is outside the workspace package list. The proposed source job should independently restore/build the reviewed inputs, verify all eleven archives, then stage those verified compile intermediates. Existing `prepare-bundled-plugins.mjs` correctly refuses stale or unverified staged inventories.

The old `build-windows-v2-package.ps1` is a delivery script with obsolete one/two-plugin count assumptions, installer and Runtime modes. It is not the P8 compile-only entry. No installer, Runtime, artifact upload, cache, release, or SDK publishing is needed for the new source gate.

## Runtime boundaries that compilation cannot close

- P6 Windows native catalog tests are real Windows evidence for their recorded revision and local-drive constraints. They do not establish WebView2 startup, worker execution, UI, IME, DPI, save/recovery, or installer correctness.
- `plugin_dom.rs` deliberately returns unavailable outside Linux. Consequently the diagrams JavaScript package may compile on Windows while its desktop DOM execution backend remains unsupported. Eleven package builds must not be reported as eleven working Windows plugin runtimes.
- Catalog sidecar trial/activation is explicitly unsupported in `plugin_catalog.rs`; raw sidecar transport code does not confer catalog support. Preserve the fail-closed gate.
- Browser target compatibility (including diagrams' es2024 output), actual Windows workers, and native UI remain separate untested gates. No SDK expansion or permission weakening is justified by these source fixes.

Windows workflow/script review is recorded separately after the owning agent freezes its new files. This audit does not attest that the not-yet-run Windows build succeeds.
