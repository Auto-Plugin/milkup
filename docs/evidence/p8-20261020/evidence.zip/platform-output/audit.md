# P8 platform DOM/output readiness audit

Read-only audit of product tree `a4d44e68` on `dot/milkup-v2-product-phase8-readiness`, 2026-10-19. No product edits, build, test execution, native GUI, installation, download or upload was performed. Only this requested evidence document was written. Historical results retain their original binary/version scope; they are not new P8 acceptance results.

## Platform facts

| Area | Actual implementation | Classification |
|---|---|---|
| Independent DOM plugin execution on Windows/macOS | `apps/desktop/src-tauri/src/plugin_dom.rs:230` permits Linux only. Prepare checks this before loading a module at line87; helper/process modules are Linux-only at15–23. | Explicitly unavailable, not merely untested. A packaged Mermaid plugin or working main WebView does not supply the isolated backend. |
| HTML export on Windows/macOS | Static HTML generation is portable, but destination selection returns unavailable at `output.rs:253`, and atomic publication is Linux-only at541/610. | Complete product HTML export is explicitly unsupported too. Do not list only PDF/print as missing. |
| PDF/printing on Windows/macOS | `output.rs:392–399` dispatches Linux WebKit only, rejecting other platforms. | Explicit implementation gap. Neither WebView2 nor WKWebView printing has been implemented/accepted by this code. |
| Strict DOM profile | Native `plugin_dom.rs:388–418`: exact document:read, no settings/networkOrigins keys, only nonempty documentRenderers contributions. Manager `desktop-plugin-manager.ts:2969` is a capability-shape check, not platform availability. | Preserve the restricted profile and native rejection. Sidecar catalog activation remains separately refused (`:2958`), irrespective of platform. |
| Linux DOM/output | Separate ephemeral WebKit process, guardian/resource guard, native output target protection and bounded leases. | Implemented with earlier real Linux evidence, with the open defects below. Not a blanket current-P8 pass or a physical-printer pass. |

Documentation already says both Windows and macOS output are unsupported: `plugins/export-print/README.md:11`. Trusted manager details only say DOM additionally needs a current-system execution environment (`desktop-plugin-manager.ts:2963`), so UI wording can be more explicit later without implementing a backend.

### Compile compatibility finding

The inspected modules correctly keep GTK/WebKit dependencies under Linux in `apps/desktop/src-tauri/Cargo.toml:30`; libc is Unix-only at27. `build.rs:48` skips the native Linux guards on other targets. `output.rs:418–431` has distinct Unix/Windows file-identity branches, and Windows calls the existing `workspace::windows_identity` (`workspace.rs:290`). Linux-only descriptor/rename calls and DOM helper tests are cfg-gated. **No specific unconditional Linux import or confirmed Windows/macOS compile error was found in this audit.** This is source inspection, not a successful target compilation. Do not invent a fix or treat Linux `cargo check` as a Windows gate.

The existing Windows catalog CI checks only its source harness, not the full desktop (`.github/workflows/v2-windows-catalog-check.yml:53,69`), is branch/commit-marker scoped, and includes toolchain installation. It must not be silently repurposed as a P8 no-download/full-desktop acceptance result. Existing package workflows also have historical delivery/authorization scopes; do not activate them just to obtain a compile check.

## Separate P4/P5/P6 outcomes

1. **PDF exact Unicode copy/search: known failure, unresolved.** Current Linux output can look correct while losing diagram Chinese characters, emoji and code quotes, with additional compatibility-glyph mapping differences. NFKC and one extractor do not establish correctness. `plugins/export-print/README.md:13`; `docs/v2-product-phase5-webkit-repair-2026-10-19.md:25,33–37`; latest P6 confirmation `docs/v2-product-phase6-plugin-lifecycle-2026-10-19.md:44,59`. The WebKit source/cluster work remains unbuilt research, not a deployed repair. The Chromium candidate was reverted and is not a current option (`webkit-repair:7–9`).
2. **Pagination: partial repair, not wholly fixed or wholly unimplemented.** Product groups a heading with its first complete paragraph/table/code/list unit (`packages/export/src/static-html.ts:172–190`) and applies soft print avoidance (`:224`). Short title/first-content and warning containment improvements remain. The actual `milestone03/native/heading-block-boundary/critical-comparison.json` shows SHORT table/code/list moved together, while long TABLE-575/CODE-575/LIST-575 still split heading from first content after wrapping. No missing markers does not prove good pagination. Long/oversized blocks remain blocked in the latest queue report (`docs/v2-product-phase5-export-queue-2026-10-19.md:53`) and P6 report (`:44,59`). Preserve oversized content; do not turn the entire block into clipping or an unbreakable container.
3. **P5 queue/preparation deadline confusion: repaired with bounded control evidence.** Previously an outer2s timer included time waiting behind editor work. The repair shares the absolute preparation deadline and preserves the native2s dispatch deadline. Seven deterministic real-RPC queue tests and actual output runs support this narrow fix (`export-queue:7–22`). This does not explain every native execution timeout.
4. **P6 first-output readiness/footnotes: repaired and actually exercised.** SDK pending is explicit, only pending providers retry every250ms within the existing per-window10s preparation deadline; owner generations and stale captures remain guarded (`docs/v2-product-phase6-plugin-lifecycle-2026-10-19.md:11–15`). First HTML/r2, A4/Letter and GTK Print-to-File had actual rich output and only the fixture’s two expected image warnings (`:43–51`). Subsequent catalog production04 cold HTML also passed (`docs/v2-product-phase6-native-catalog-2026-10-19.md:84`). These are positive ready/first-footnote results, not PDF Unicode/pagination fixes. “First output” is not necessarily the renderer’s first execution because the editor may request screen content.
5. **Historical Print-file04: unresolved native execution timeout.** `render_1` exceeded2000.313ms after native dispatch, caused Mermaid source fallback and failed rich printing. The old record does not identify a deeper renderer phase. Later queue/ready fixes and successful cold printing cannot erase or causally close that failure (`export-queue:51`; `webkit-repair:47`).
6. **P4 long-session Sankey timeout: separate unresolved failure.** `render_1037` dispatched then hit2027.576399ms in the final narrow/dark/200% windowed scenario. It is not Print04’s request or the same proven bug. Exact trace/failed-prefix boundary: `docs/v2-product-phase4-mermaid-engine-2026-10-16.md:705–715`. Existing label overlap/author color/canvas whitespace findings remain separately qualified there; no general diagram-layout pass is inferred.
7. **Physical printing and cancellation after queue submission: unverified.** GTK Print-to-File PDF proves neither physical printer output nor cancellation of a spooler job. Current export-print1.0.0 cancels its operation immediately (`plugins/export-print/src/controller.ts:64–72`); the later confirmation-handshake research was reverted (`webkit-repair:7`). Do not describe the abandoned1.0.1 behavior as current. Existing selector cancellation/helper cleanup and document-edit isolation evidence remains valid within its tested scope.

## Ranked narrow recommendations

### P0 — Pin compile/version/negative-platform gates before delivery

Use the exact P8 source, Cargo.lock, plugin archive inventory and installed toolchain. Add/execute a **full desktop** compile gate on actual Windows with installed MSVC/SDK (and on actual macOS only when available). No Runtime or engine download is necessary merely to inspect source/compile prerequisites; missing prerequisites should stop with a recorded blocker, not trigger installation. Keep cfg-gated unsupported backends. Generic profile/catalog success is not platform execution support.

Suggested no-download compile command, run only in the proper prepared target environment:

```sh
cargo check --locked --offline --manifest-path apps/desktop/src-tauri/Cargo.toml --all-targets --target x86_64-pc-windows-msvc
```

Then actual Windows library execution with existing dependencies:

```sh
cargo test --locked --offline --manifest-path apps/desktop/src-tauri/Cargo.toml --lib --target x86_64-pc-windows-msvc -- --test-threads=1
```

An analogous installed `aarch64-apple-darwin` or `x86_64-apple-darwin` toolchain can compile on the corresponding prepared Mac. Cross-compilation is only compile evidence. A successful catalog-only source test must not substitute for either command or desktop UI acceptance.

Add small target-specific negative tests for DOM and HTML/PDF/print unsupported behavior: stable errors, no committed files, no spawned helper and no leaked allocation. Current output tests are Linux-only (`output.rs:630`), so unsupported stubs do not yet have an equivalent explicit platform gate. This is a concrete, low-risk readiness improvement, not a new backend.

### P1 — Fail unsupported output early and explain it accurately

`output-service.ts:113–330` captures/scans/renders content before calling native prepare. `output_prepare_inner` (`output.rs:186`) currently allocates a lease on any platform; rejection occurs later at chooser/render/publication. A native support check before allocation is safe and avoids retained unsupported jobs; an internal trusted capability/preflight check before expensive capture would improve UX further. Keep the trusted gesture, version/cancellation boundaries and public SDK unchanged. If only the native prepare check is added, do not claim all frontend preparation work was avoided. Prefer a neutral explicit “HTML/PDF/printing unavailable on this platform” rather than implying missing Runtime installation will fix it. Do not use navigator.userAgent as the authority for permission/support enforcement.

### P1 — Preserve CRLF/version/cancel contracts while proving current binaries

Re-run existing bounded capture and queue regressions with the exact current source: terminal CR, CRLF reconstruction, UTF-16 lengths, half-surrogate rejection, selection scope, captured-version/source-path-generation binding, queued/active cancellation and late-owner results. Relevant tests are `apps/desktop/src/output-service.test.ts:211–349` and `output-presentations-queue.test.ts:217–405`. These are executable without new dependencies using the installed Vitest:

```sh
# cwd apps/desktop
node ../../node_modules/vitest/vitest.mjs run src/output-service.test.ts src/output-presentations-queue.test.ts src/plugin-dom.test.ts
# cwd packages/export
node ../../node_modules/vitest/vitest.mjs run src/static-html.test.ts
```

Before native gates, pin installed plugin versions (export-print1.0.0, diagrams1.1.1, footnotes1.0.1 or the exact accepted successors) and final binary hash. Existing P6 harness contains historical outline1.3.1 assumptions (`tests/native/tauri-p6-lifecycle.mjs:9`); use a clearly versioned harness copy/parameters where needed, never silently change an old run or install an unverified replacement.

### P2 — Keep WebKit fidelity/timeout gates independent

On prepared Linux, use existing real UI fixtures to generate A4, Letter and GTK Print-to-File output, plus first/r2 output and cancellation/edit/undo/save. Reuse `tauri-p6-lifecycle.mjs` cold-output/cold-edit modes and the P5 diagram/large fixtures; no private output IPC. Validate actual PDF bytes/page dimensions, all content markers and SVG geometry, then inspect every page and separately compare raw original Unicode text with at least independent extraction paths. Preserve known FAIL when exact text is wrong even if pixels are correct. Re-run short and oversized table/code/list heading cases; source completeness and no blank pages are necessary but not sufficient for pagination pass.

For historical native timeouts, retain exact package/input/generation/dispatch/deadline/terminal records. Any extra instrumentation belongs in a separate diagnostic run. No deadline increase, speculative cache, Chromium backend, global library replacement or Runtime/font download is justified by this readiness audit. A full WebKit patch still needs build/ABI/distribution feasibility and real rendering regressions before acceptance.

## Minimum real-platform conditions for later gates

- **Windows compile:** actual Windows host, already-installed pinned Rust MSVC target, MSVC linker/Windows SDK and locked cached dependencies. Record versions/source hashes. No WebView2 GUI claim follows from compiling.
- **Windows desktop:** separately authorized existing Runtime and interactive Windows desktop, exact installed executable provenance, fresh profile, real input/clipboard/CRLF file tests and source hashes. DOM/output should currently show their unsupported boundary; implementing those backends is outside this readiness scope. Windows catalog filesystem tests do not supply WebView/Worker/UI/DPI evidence.
- **macOS:** real supported Mac architecture and prepared Apple toolchain/WebKit environment; compile and actual UI tests are separate. Current native DOM/output unavailable remains the expected result, not a WKWebView implementation waiting for screenshots.
- **Linux output:** existing WebKitGTK/GTK/font environment plus native sandbox/guard availability, owned interactive display/driver, fixed source and archives, actual chooser and print-file backend, recorded process ownership. Physical-printer acceptance additionally needs a real queue/device and observable submit/cancel/output outcome; a print-file choice is insufficient.

No platform expansion is recommended in this P8 checkpoint. Immediate scope should be compile compatibility, explicit unsupported behavior, CRLF/cancel/version safety and honest release gates. Product source remained unchanged after this audit.
