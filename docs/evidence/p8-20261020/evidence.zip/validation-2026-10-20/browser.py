import os,json,subprocess,datetime,time
from pathlib import Path
out=Path(__file__).parent;env=os.environ.copy();env.update(NPM_CONFIG_VERIFY_DEPS_BEFORE_RUN='false',NPM_CONFIG_MANAGE_PACKAGE_MANAGER_VERSIONS='false',COREPACK_ENABLE_NETWORK='0',MILKUP_BROWSER_EXECUTABLE='/usr/bin/chromium',PLAYWRIGHT_JSON_OUTPUT_FILE=str(out/'updates-browser.json'))
cmd=['bash','scripts/cloud/pnpm.sh','--config.verify-deps-before-run=false','--config.manage-package-manager-versions=false','exec','playwright','test','tests/e2e/desktop-updates.spec.ts','--project=desktop-msedge','--workers=1','--retries=0','--reporter=list,json']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
with (out/'updates-browser.log').open('wb') as log:p=subprocess.run(cmd,cwd='/workspace/milkup',env=env,stdout=log,stderr=subprocess.STDOUT)
record=dict(command=cmd,startedAt=start,seconds=time.monotonic()-clock,exitCode=p.returncode,browser='/usr/bin/chromium',scope='Browser Worker/public SDK UI, native transport is fixture; not Windows installer or native GUI')
(out/'updates-browser-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
