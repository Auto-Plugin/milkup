import subprocess,os,json,time,datetime
from pathlib import Path
root=Path('/workspace/milkup'); out=Path(__file__).parent
base=['bash','scripts/cloud/pnpm.sh','--config.verify-deps-before-run=false','--config.manage-package-manager-versions=false']
env=os.environ.copy();env.update(NPM_CONFIG_VERIFY_DEPS_BEFORE_RUN='false',NPM_CONFIG_MANAGE_PACKAGE_MANAGER_VERSIONS='false',COREPACK_ENABLE_NETWORK='0')
results=[]
for name,args in [('workspace-test',['test']),('workspace-typecheck',['typecheck']),('workspace-build',['build'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
 with (out/(name+'.log')).open('wb') as log: p=subprocess.run(base+args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 item=dict(name=name,command=base+args,startedAt=start,elapsedSeconds=time.monotonic()-clock,exitCode=p.returncode)
 results.append(item); (out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(item),flush=True)
