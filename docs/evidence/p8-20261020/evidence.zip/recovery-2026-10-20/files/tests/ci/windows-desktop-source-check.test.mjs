import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { test } from 'node:test'

const read = (name) => readFile(new URL(`../../${name}`, import.meta.url), 'utf8')

test('P8 source job has independent public branch/marker gates and no delivery actions', async () => {
  const workflow = await read('.github/workflows/v2-windows-catalog-check.yml')
  const job = workflow.split('\n  desktop-source:\n')[1]
  assert.ok(job, 'Missing independent P8 desktop source job')
  for (const clause of [
    "github.repository == 'Auto-Plugin/milkup'",
    "github.ref == 'refs/heads/dot/milkup-v2-product-phase8-readiness'",
    'github.event.repository.private == false',
    'github.event.deleted == false',
    "contains(github.event.head_commit.message, '[windows-desktop-source-check]')",
    'runs-on: windows-2025',
    'timeout-minutes: 60',
    'persist-credentials: false',
    'a4d44e680478d7894450f30f3d533dc1c3131974',
  ])
    assert.ok(job.includes(clause), `Missing gate: ${clause}`)
  assert.doesNotMatch(
    job,
    /upload-artifact|actions\/cache|--bundles|build-windows-v2-package|webviewInstallMode|secrets\./i,
  )
  assert.match(workflow, /\[windows-catalog-check\]/)
  assert.match(workflow, /run-windows-baseline\.ps1/)
})

test('source script checks, tests and links actual production app without bundler', async () => {
  const script = await read('scripts/ci/check-windows-desktop-source.ps1')
  for (const command of [
    "'install', '--frozen-lockfile'",
    "'test'",
    "'typecheck'",
    "'build'",
    'verify-public-plugin-builds.mjs',
    'stage-public-plugin-check.mjs',
    "'check', '--locked'",
    "'--all-targets'",
    'test-windows-rust-library.ps1',
    "'build', '--locked'",
    "'--release'",
    "'tauri/custom-protocol'",
    'verify-windows-app-manifest.ps1',
    'rust-test-result.json',
    '$LASTEXITCODE',
    'phases.json',
  ])
    assert.ok(script.includes(command), `Missing phase/exit evidence: ${command}`)
  assert.doesNotMatch(
    script,
    /--bundles|\bnsis\b|tauri\s+build|downloadBootstrapper|offlineInstaller|upload-artifact/i,
  )
  assert.match(script, /x86_64-pc-windows-msvc/)
  assert.match(script, /RUST_TEST_THREADS\s*=\s*'1'/)
})
