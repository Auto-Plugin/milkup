# CI03 resource/recovery Access denied diagnosis and narrow fix

CI03 retains eight real Windows failures: seven resources tests and recovery's resource-copy/reopen test. Their full original log is `../ci03/run-logs/0_desktop-source.txt`; its SHA and an extracted failure section are retained here. No RED log was overwritten or reclassified as passing.

All eight failing paths converge on `resources::write_staged`: new exclusive file creation, identity capture, byte writes, `file.sync_all`, then `directory.file.sync_all` (old line 479). Recovery enters via `restore_resources -> restore_recovery_resources -> copy_managed_resources -> write_staged`; imports enter via `stage_images -> write_staged`.

The specific source diagnosis is the directory `File::sync_all`, which uses Windows FlushFileBuffers. `workspace::open_child` and `open_absolute_directory` intentionally obtain read-only directory handles with OPEN_REPARSE_POINT/BACKUP_SEMANTICS and no FILE_SHARE_DELETE. Microsoft's [FlushFileBuffers contract](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-flushfilebuffers) requires GENERIC_WRITE; [CreateFile sharing rules](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew) explain why retained no-delete handles prevent rename/replacement. CI03's bare errors do not independently identify the syscall; the new Windows regression directly characterizes it instead of treating every Access denied error as benign.

## Fix

`Directory::sync_written_file` strictly flushes the writable new file, then revalidates the guarded directory identity and no-reparse traversal. On Unix it still strictly flushes the directory. Windows does not attempt an invalid read-only directory flush. No failed flush is caught and discarded, and file errors still enter the existing identity/content-checked cleanup path. No workspace helper, share flags, path authorization, byte limit, recovery provenance, or transaction acceptance rule changes.

Windows semantics match the already accepted P6 catalog boundary: file flush and pinned-directory validation, **no POSIX directory metadata durability barrier and no arbitrary power-loss guarantee**. The resources module explicitly documents this limitation. It does not claim GUI or installed-application acceptance.

## Regression scope

- `staged_file_sync_rejects_mismatched_directory_identity` is cross-platform: a directory path/handle mismatch must fail while the original bytes remain unchanged and no file appears in the other directory.
- `windows_staged_file_flush_preserves_directory_guards_and_propagates_file_errors` is Windows-only: the exact guarded directory flush must return OS5; the writable leaf flush and validation succeed; flushing a read-only leaf still returns OS5; renaming the pinned directory still returns sharing violation OS32. It releases all test handles before deleting its private fixture.
- Existing resources and recovery tests preserve the eight CI03 RED scenarios as end-to-end native unit regressions. No assertions are weakened.

This agent ran rustfmt and whitespace validation only. Root owns serialized Linux compilation/test execution; Windows CI must execute the new real-OS regression and original failures. `diagnosis.json` records exact source/log hashes and scope. No commit, push, dependency, installer, arbitrary process or permission change was made by this agent.
