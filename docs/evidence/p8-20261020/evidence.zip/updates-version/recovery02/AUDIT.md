# P8 updates/version recovery02 audit (2026-10-20)

## Findings and fixes

- Read `docs/cloud-environment-v2.md` and P8 checklist before changing files. This recovery started from the existing uncommitted P8 snapshot at HEAD `a4d44e680478d7894450f30f3d533dc1c3131974`.
- Latest historical `../rust-updates-full01.log/json` is **11 passed, zero failed, exit 0**. Both current updates source hashes and the preserved binary hash exactly match it. This is historical exact-source evidence, not a newly rebuilt candidate binary. `prior-updates-evidence-review02.json` records the comparison. No cargo compilation or cache closure rebuild was run.
- The existing `download_epoch` implementation correctly rejects cancelled/stale late completions while preserving the release token for retry and keeping newer abort handles armed. Its five deterministic publication tests remain unchanged.
- Found an additional Cargo.toml cross-table failure: a missing package version followed by an indented dependency table could borrow/write the dependency version. Added space/tab-header regression cases; `node-red02.log` fails before the narrow header-boundary fix, `node-green02.log` passes afterward. No full TOML parser or new dependency was added. Application version remains `2.0.0-beta.1`.
- Strengthened the existing host tests: after a returned install error, installation state and focus recover; stale confirmation stays inert; retry requires a fresh confirmation/document preparation and another verified download of the same release. These are **mocked transport/host contracts**, not Windows startup evidence.

## Windows updater fix and provenance

Pinned upstream tauri-plugin-updater 2.10.1 (`src/updater.rs` original lines 837–865) invokes cleanup before launch, discards ShellExecuteW's result, then exits unconditionally. `UpdaterExt::updater_builder` supplies `AppHandle::cleanup_before_exit` by default, so checking launch status without moving cleanup would be insufficient.

Root explicitly authorized vendoring the same version and applying a narrow patch. The local source came from the already-cached crate. The archive SHA-256 `806d9dac662c2e4594ff03c647a552f2c9bd544e7d0f683ec58f872f952ce4af` equals the previous Cargo.lock checksum. All 29 original files were verified; only `src/lib.rs` and `src/updater.rs` change, with one added private `src/windows_install.rs`. All original licenses and dependency manifests are unchanged. The original vendor Cargo.lock is preserved as an upstream artifact; application resolution uses the desktop Cargo.lock.

The private helper calls the existing ShellExecuteW path/arguments. Status <=32 returns Error::Io(Other), with the actual numeric status in the message, **before cleanup or exit**. Status >32 calls cleanup then exit. This introduces no public arbitrary execution path, installer, signature bypass, key, endpoint, new dependency, or version change. OS acceptance does not imply installer completion or application restart success.

`vendor/tauri-plugin-updater/MILKUP-PATCH.md`, `MILKUP-PATCH.diff`, and `MILKUP-PROVENANCE.json` make the exact local deviation reviewable. Node guard verifies original/current hashes, rejects unexpected vendor files, and checks exact local updater lock selection/dependencies. `.prettierignore` excludes the narrow vendor directory to preserve original bytes; p8_windows owns the matching `.gitattributes` rule.

## Verification actually completed here

- Node version/provenance tests: **9 passed**; `node-final02.log/json`.
- Current version gate: **exit 0**, application beta.1; `version-final02.log/json`.
- Vendor hash/closure gate: **exit 0**; `updater-vendor-final02.log/json`.
- Host installation recovery tests: **24 passed** across two test files; `host-final02.log/json`.
- Standalone Rust production policy test on Linux: unchecked-result mutation **RED exit 101**, reviewed implementation **GREEN 1 passed / exit 0**; `windows-policy-red02.*`, `windows-policy-green02.*`. This RED reproduces the unchecked-result policy, not execution of the original Windows dependency. Real Windows code is cfg-excluded in these Linux runs.
- `cargo metadata --locked --offline` full dependency resolution: **exit 0**; `cargo-metadata-full02.json`. This is metadata validation, not compilation.
- Parsed old/new Cargo.lock comparison: all packages/versions/dependency edges identical; only updater source/checksum removed for path override; `lock-closure-comparison02.json`.
- Targeted rustfmt, prettier and git diff whitespace checks passed.
- Root separately reports browser update suite 14/14: `/workspace/milkup-p8-readiness-evidence/validation-2026-10-20/updates-browser-result.json`; this agent did not rerun it.

## Windows execution / remaining boundaries

p8_windows is wiring explicit dependency tests (desktop --lib does not run dependency tests), listing and requiring both exact names before execution:

1. `windows_install::tests::rejected_launch_preserves_app_and_can_be_retried`: actual production result-classification helper with rejected statuses and fake accepted status; no process launch.
2. `windows_install::tests::real_missing_executable_returns_error_without_cleanup_or_exit`: **Windows only**, invokes the actual production ShellExecuteW helper twice with an absent executable under a newly-created private temp directory containing a Unicode/space filename. It writes no executable, starts no installer, and asserts errors with neither cleanup nor exit callback invoked.

**No Windows runtime result is claimed in this audit.** The Windows CI result remains pending the parent workflow. It will validate real OS launch failure at the production helper boundary, not a complete installed desktop GUI/UAC flow. Actual installer success, denied elevation, upgrade rollback, post-install startup failure, package production/signing/distribution and full platform GUI acceptance remain separate gates. Existing host semantics consume verified bytes on an install attempt, so recovery intentionally requires a fresh verified download rather than promising an immediate no-download retry.

No commit, push, workflow change, installer generation or artifact upload was performed by this agent. Final source hashes are in `final-inputs02.json`; parent owns commits and CI.
