from pathlib import Path
import subprocess,json,time,sys,datetime,zipfile,re
run_id,sha,case=sys.argv[1:]
root=Path('/workspace/milkup-w0-udp-evidence')/case
root.mkdir(parents=True,exist_ok=True)
api=f'repos/Auto-Plugin/milkup/actions/runs/{run_id}'
def fetch(suffix='',binary=False):
 p=subprocess.run(['gh','api',api+suffix],capture_output=True,timeout=60)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout if binary else json.loads(p.stdout)
def save(name,data): (root/name).write_text(json.dumps(data,indent=2)+'\n')
while True:
 try:
  run=fetch();assert run['head_sha']==sha
  jobs=fetch('/jobs');artifacts=fetch('/artifacts')
  save('run.json',run);save('jobs.json',jobs);save('artifacts.json',artifacts)
  row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':run['status'],'conclusion':run['conclusion'],'sha':sha,'artifactCount':artifacts['total_count']}
  with (root/'polls.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  print(json.dumps(row),flush=True)
  if run['status']=='completed':break
 except Exception as e:
  with (root/'monitor-errors.log').open('a') as f:f.write(str(e)+'\n')
 time.sleep(45)
(root/'run-logs.zip').write_bytes(fetch('/logs',True))
with zipfile.ZipFile(root/'run-logs.zip') as z:
 assert z.testzip() is None
 for n in z.namelist():
  p=Path(n);assert not p.is_absolute() and '..' not in p.parts
 z.extractall(root/'run-logs')
for p in (root/'run-logs').rglob('*.txt'):
 if '/desktop-source/' not in str(p) and '/windows-w0/' not in str(p):continue
 text='\n'.join(re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT[^ ]+ ','',l) for l in p.read_text(encoding='utf-8-sig').splitlines())
 for match in re.finditer(r'^##\[group\]([^\r\n]+)\n(.*?)^##\[endgroup\]',text,re.M|re.S):
  name,body=match.groups()
  if name in ['windows-w0-matrix.json','windows-w0-platform.json','windows-w0-policy-before.json','windows-w0-policy-after.json','windows-w0-probe.json','windows-backend-environment.json','source.json','phases.json','rust-test-result.json','production-binary-manifest.json','public-plugins/staged-bundles.json']:
   start=body.find('{') if body.lstrip()[:1]!='[' else body.index('[')
   if start<0:raise ValueError('Missing JSON body '+name)
   if body[:start].strip():(root/(Path(name).stem+'-interleaved.log')).write_text(body[:start])
   lines=body[start:].splitlines()
   separated=[{'groupLine':i+1,'text':line} for i,line in enumerate(lines) if line.startswith('W0 probe failed: ')]
   if separated:
    save(Path(name).stem+'-parse-provenance.json',{'rawLog':str(p.relative_to(root)),'separatedStderrLines':separated,'transformation':'Only timestamp prefixes and these exact standalone stderr lines separated; original ZIP/log unchanged'})
    body=body[:start]+'\n'.join(line for line in lines if not line.startswith('W0 probe failed: '))
   value,end=json.JSONDecoder().raw_decode(body[start:])
   if body[start+end:].strip():raise ValueError('Unexpected trailing JSON data '+name)
   save(Path(name).name,value)
  elif re.fullmatch('[a-z][a-z-]+',name):
   (root/(name+'.log')).write_text(re.sub(r'\x1b\[[0-9;]*m','',body))
print('LOGS COMPLETE '+str(root),flush=True)
