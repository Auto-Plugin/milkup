from pathlib import Path
import re,json
root=Path('/workspace/milkup-w0-udp-evidence/D03-async-policy')
p=next((root/'run-logs/windows-w0').glob('6_*'))
s='\n'.join(re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT[^ ]+ ','',l) for l in p.read_text(encoding='utf-8-sig').splitlines())
for match in re.finditer(r'^##\[group\]([^\r\n]+)\n(.*?)^##\[endgroup\]',s,re.M|re.S):
 name,body=match.groups()
 if name not in ['windows-w0-matrix.json','windows-w0-platform.json','windows-w0-policy-before.json','windows-w0-policy-after.json']:continue
 lines=body.splitlines(); separated=[];keep=[]
 for i,line in enumerate(lines):
  if line.startswith('W0 probe failed: ') or line.startswith('\x1b[31;1m'):
   separated.append({'groupLine':i+1,'text':line})
  else: keep.append(line)
 if separated:
  assert len(separated)==6 and separated[0]['groupLine']==94908
  (root/'windows-w0-matrix-parse-provenance.json').write_text(json.dumps({'rawLog':str(p.relative_to(root)),'separatedStderrLines':separated,'transformation':'Only timestamp prefixes and the six exactly recorded standalone native/PowerShell stderr lines separated. Original ZIP and extracted logs unchanged.'},indent=2)+'\n')
 value=json.loads('\n'.join(keep));(root/name).write_text(json.dumps(value,indent=2)+'\n')
 print(name,'parsed',len(separated),'stderr lines separated')
