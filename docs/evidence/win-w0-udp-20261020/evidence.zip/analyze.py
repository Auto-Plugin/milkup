from pathlib import Path
import json,collections,sys
root=Path(sys.argv[1]);r=json.loads((root/'windows-w0-matrix.json').read_text())
events=r.get('endpointObservationsFinal',[])
rows=[]
for case in r['cases']:
 child=case.get('child',{})
 for phase,key in [('before-runtime','udpBeforeRuntime'),('after-runtime','udpAfterRuntime')]:
  probe=child.get(key,{})
  for variant in probe.get('cases',[]):
   received=[e for e in events if e.get('nativeMarker')==variant['marker']]
   owners=[owner for e in received for owner in e.get('socketOwners',{}).get('owners',[])]
   bindings=[binding for e in received for binding in e.get('socketOwners',{}).get('bindings',[])]
   rows.append({'case':case['name'],'phase':phase,'family':variant['family'],'variant':variant['variant'],'target':variant['target'],'marker':variant['marker'],'localAfterBind':variant.get('localAfterBind'),'localAfterSend':variant.get('localAfterSend'),'sendResult':variant.get('sendResult'),'connectResult':variant.get('connectResult'),'holdMs':variant['holdMs'],'received':len(received),'reply':variant.get('reply'),'owners':owners,'bindings':bindings,'threadImpersonation':probe.get('threadImpersonation'),'helperPid':probe.get('pid'),'helperToken':probe.get('token')})
summary={'source':r['source'],'cases':[{k:c.get(k) for k in ['name','completed','error','observedDurationMs','accountingAfterStop']} for c in r['cases']],'rows':rows,'turn':dict(collections.Counter(f"{e.get('turnUsername')}/{e.get('family')}" for e in events if e.get('turnUsername'))),'fullIsolationGatePassed':r['fullIsolationGatePassed'],'networkCanaryGatePassed':r.get('networkCanaryGatePassed'),'cleanup':{k:r.get(k)for k in ['cleanupErrors','outsideFileUnchanged','privateTreeAndAclRemoved','profileDeletedAndFolderAbsent']},'exemptions':{k:v for k,v in r.items()if k.startswith('loopbackExemptions')}}
(root/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k!='rows'},ensure_ascii=False,indent=2))
for row in rows:print(row['case'],row['phase'],row['family'],row['variant'],'received',row['received'],'send',row['sendResult'],'echo',row['reply'])
