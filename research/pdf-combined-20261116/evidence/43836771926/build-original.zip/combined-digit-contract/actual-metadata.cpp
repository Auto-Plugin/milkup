#include "ScalarGlyphText.h"
#include <cassert>
using namespace WebCore;
// Research only. Caller must retain LTR/horizontal TextRun and actual offset
// provenance guards. This does not infer source characters from glyph IDs.
static std::optional<ScalarGlyphText> makeIndependentAsciiDigitText(
    std::u16string_view source, std::span<const uint32_t> offsets,
    std::span<const uint32_t> drawnGlyphs, std::span<const uint32_t> nominalGlyphs)
{
    if (source.empty() || source.size() > ScalarGlyphText::maxBytes / 4
        || offsets.size() != drawnGlyphs.size() || offsets.size() != nominalGlyphs.size())
        return std::nullopt;
    // acceptedGlyphs is deliberately NOT described as a font cmap. Unchanged
    // glyphs retain the nominal requirement; only a valid ASCII digit source
    // may supply a different actual shaped glyph. No output glyph is changed.
    std::vector<uint32_t> acceptedGlyphs(nominalGlyphs.begin(), nominalGlyphs.end());
    for (size_t i = 0; i < offsets.size(); ++i) {
        if (drawnGlyphs[i] == nominalGlyphs[i])
            continue;
        if (offsets[i] >= source.size() || source[offsets[i]] < u'0' || source[offsets[i]] > u'9'
            || !nominalGlyphs[i] || nominalGlyphs[i] >= 0xFFFF
            || !drawnGlyphs[i] || drawnGlyphs[i] >= 0xFFFF)
            return std::nullopt;
        acceptedGlyphs[i] = drawnGlyphs[i];
    }
    // The unchanged helper proves complete one-scalar/one-glyph coverage of
    // the WHOLE span: exact increasing UTF-16 offsets, no repeated/missing
    // clusters, extra glyphs, ligatures or malformed surrogate pairs. Preserve
    // original text for Skia's existing extended-map/ActualText conflict path.
    return makeScalarGlyphText(source, offsets, drawnGlyphs, acceptedGlyphs);
}

int main() {
{
std::u16string text {87,82,65,80,48,49,50,51,52,53,54,55,56,57};
std::vector<uint32_t> offsets {0,1,2,3,4,5,6,7,8,9,10,11,12,13}, glyphs {56,51,34,49,63153,63154,63155,63156,63157,63158,63159,63160,63161,63162}, nominal {56,51,34,49,17,18,19,20,21,22,23,24,25,26};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == true);
assert(candidate->utf8 == std::string("WRAP0123456789", 14));
std::string joined; for (size_t i=0; i<glyphs.size(); ++i) joined += candidate->slice(i,1)->utf8; assert(joined == candidate->utf8);
}
{
std::u16string text {87,82,65,80,48,49,50,51,52,53,54,55,56,57};
std::vector<uint32_t> offsets {0,1,2,3,4,5,6,7,8,9,10,11,12,13}, glyphs {56,51,34,49,17,18,19,20,21,22,23,24,25,26}, nominal {56,51,34,49,17,18,19,20,21,22,23,24,25,26};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == true); assert(candidate.has_value() == true);
assert(candidate->utf8 == std::string("WRAP0123456789", 14));
std::string joined; for (size_t i=0; i<glyphs.size(); ++i) joined += candidate->slice(i,1)->utf8; assert(joined == candidate->utf8);
}
{
std::u16string text {25991,12098,39118,11995,21448,12060,26376,12105};
std::vector<uint32_t> offsets {0,1,2,3,4,5,6,7}, glyphs {20036,20036,44285,44285,11858,11858,20694,20694}, nominal {20036,20036,44285,44285,11858,11858,20694,20694};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == true); assert(candidate.has_value() == true);
std::string joined; for (size_t i=0; i<glyphs.size(); ++i) joined += candidate->slice(i,1)->utf8; assert(joined == candidate->utf8);
}
{
std::u16string text {49,50,49,50};
std::vector<uint32_t> offsets {0,1,2,3}, glyphs {3,3,3,3}, nominal {1,2,1,2};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == true);
assert(candidate->utf8 == std::string("1212", 4));
std::string joined; for (size_t i=0; i<glyphs.size(); ++i) joined += candidate->slice(i,1)->utf8; assert(joined == candidate->utf8);
}
{
std::u16string text {102,105};
std::vector<uint32_t> offsets {0}, glyphs {6}, nominal {4};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == false);
}
{
std::u16string text {97,769};
std::vector<uint32_t> offsets {0}, glyphs {9}, nominal {7};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == false);
}
{
std::u16string text {120,769};
std::vector<uint32_t> offsets {0,0}, glyphs {91,690}, nominal {91,91};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == false);
}
{
std::u16string text {1587,1604,1575,1605};
std::vector<uint32_t> offsets {3,2,1,0}, glyphs {482,1565,448,250}, nominal {482,3,445,247};
auto old = false ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = false ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == false);
}
{
std::u16string text {2325,2367};
std::vector<uint32_t> offsets {0,0}, glyphs {607,25}, nominal {25,25};
auto old = true ? makeScalarGlyphText(text, offsets, glyphs, nominal) : std::nullopt;
auto candidate = true ? makeIndependentAsciiDigitText(text, offsets, glyphs, nominal) : std::nullopt;
assert(old.has_value() == false); assert(candidate.has_value() == false);
}
{
      const std::u16string source = u"12";
      const std::vector<uint32_t> nominal {1,2}, good {3,3};
      for (auto offsets : {std::vector<uint32_t>{0}, {0,0}, {1,0}, {0,2}, {1,2}, {0,1,1}})
        assert(!makeIndependentAsciiDigitText(source, offsets, good, nominal));
      for (auto bad : {std::vector<uint32_t>{0,3}, {65535,3}, {65536,3}})
        assert(!makeIndependentAsciiDigitText(source, {std::vector<uint32_t>{0,1}}, bad, nominal));
      assert(!makeIndependentAsciiDigitText(source, {std::vector<uint32_t>{0,1}}, good, {std::vector<uint32_t>{0,2}}));
      assert(!makeIndependentAsciiDigitText(u"ab", {std::vector<uint32_t>{0,1}}, good, nominal));
      assert(!makeIndependentAsciiDigitText(u"١٢", {std::vector<uint32_t>{0,1}}, good, nominal));
    }
}