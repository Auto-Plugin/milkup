import gi,json,os,sys
gi.require_version('Gtk','3.0')
from gi.repository import Gtk
w=Gtk.Window(title='MILKUP_UPDATE_PLUMBING');w.set_default_size(480,160)
e=Gtk.Entry();w.add(e)
def close(*unused):
 value=e.get_text();print(json.dumps({'pid':os.getpid(),'text':value,'normalDeleteEvent':True}),flush=True)
 Gtk.main_quit();return False
w.connect('delete-event',close);w.show_all();e.grab_focus();Gtk.main()
